package fr.cobblepulse.crates.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import fr.cobblepulse.crates.Crates;
import fr.cobblepulse.crates.builder.BuilderService;
import fr.cobblepulse.crates.config.Cfg;
import fr.cobblepulse.crates.config.CrateDef;
import fr.cobblepulse.crates.config.Locations;
import fr.cobblepulse.crates.core.Msg;
import fr.cobblepulse.crates.core.Perms;
import fr.cobblepulse.crates.core.Reg;
import fr.cobblepulse.crates.core.TextUtil;
import fr.cobblepulse.crates.crate.CrateService;
import fr.cobblepulse.crates.crate.Links;
import fr.cobblepulse.crates.crate.Rewards;
import fr.cobblepulse.crates.item.KeyType;
import fr.cobblepulse.crates.item.ModItems;
import fr.cobblepulse.crates.net.Net;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** /lootbox (caisses) et /cpbuilder (menu Voeu ADN). */
public final class Commands {
    private Commands() {}

    private static final SuggestionProvider<class_2168> CRATES = (ctx, b) -> class_2172.method_9265(Cfg.CRATES.keySet(), b);
    private static final SuggestionProvider<class_2168> KEYS = (ctx, b) -> {
        List<String> s = new ArrayList<>();
        for (KeyType k : KeyType.values()) s.add(k.shortName);
        for (String c : Cfg.CRATES.keySet()) if (!s.contains(c)) s.add(c);
        return class_2172.method_9265(s, b);
    };

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(method_9247("lootbox")
                .then(method_9247("preview").requires(Perms.playerReq(Perms.PREVIEW))
                        .then(method_9244("nom", StringArgumentType.word()).suggests(CRATES).executes(Commands::preview)))
                .then(method_9247("set").requires(Perms.adminReq(Perms.ADMIN_SET))
                        .then(method_9244("nom", StringArgumentType.word()).suggests(CRATES).executes(Commands::set)))
                .then(method_9247("unset").requires(Perms.adminReq(Perms.ADMIN_UNSET))
                        .executes(ctx -> unset(ctx, null))
                        .then(method_9244("nom", StringArgumentType.word()).suggests(CRATES).executes(ctx -> unset(ctx, StringArgumentType.getString(ctx, "nom")))))
                .then(method_9247("editor").requires(Perms.adminReq(Perms.ADMIN_EDITOR)).executes(Commands::editor))
                .then(method_9247("toggle").requires(Perms.adminReq(Perms.ADMIN_TOGGLE))
                        .then(method_9244("nom", StringArgumentType.word()).suggests(CRATES).executes(Commands::toggle)))
                .then(method_9247("toggleall").requires(Perms.adminReq(Perms.ADMIN_TOGGLE)).executes(Commands::toggleAll))
                .then(method_9247("givekey").requires(Perms.adminReq(Perms.ADMIN_GIVEKEY))
                        .then(method_9244("joueur", class_2186.method_9308())
                                .then(method_9244("cle", StringArgumentType.word()).suggests(KEYS)
                                        .executes(ctx -> giveKey(ctx, 1))
                                        .then(method_9244("quantite", IntegerArgumentType.integer(1, 6400))
                                                .executes(ctx -> giveKey(ctx, IntegerArgumentType.getInteger(ctx, "quantite")))))))
                .then(method_9247("givewish").requires(Perms.adminReq(Perms.ADMIN_GIVEWISH))
                        .then(method_9244("joueur", class_2186.method_9308())
                                .executes(ctx -> giveWish(ctx, 1))
                                .then(method_9244("quantite", IntegerArgumentType.integer(1, 6400))
                                        .executes(ctx -> giveWish(ctx, IntegerArgumentType.getInteger(ctx, "quantite"))))))
                .then(method_9247("reload").requires(Perms.adminReq(Perms.ADMIN_RELOAD)).executes(Commands::reload))
                .then(method_9247("list").requires(Perms.adminReq(Perms.ADMIN_EDITOR)).executes(Commands::list))
                .then(method_9247("selftest").requires(src -> SelfTest.enabled() && src.method_9259(2))
                        .executes(ctx -> SelfTest.run(ctx.getSource()))
                        .then(method_9247("persisted").executes(ctx -> SelfTest.persisted(ctx.getSource())))
                        .then(method_9247("live").executes(ctx -> SelfTest.live(ctx.getSource())))
                        .then(method_9247("report").executes(ctx -> SelfTest.report(ctx.getSource())))));
        d.register(method_9247("cpbuilder").requires(Perms.playerReq(Perms.BUILDER_OPEN)).executes(ctx -> {
            class_3222 p = player(ctx);
            if (p != null) BuilderService.open(p);
            return 1;
        }));
    }

    private static class_3222 player(CommandContext<class_2168> ctx) {
        class_3222 p = ctx.getSource().method_44023();
        if (p == null) Msg.send(ctx.getSource(), "general.players_only");
        return p;
    }

    private static CrateDef crateArg(CommandContext<class_2168> ctx) {
        String id = StringArgumentType.getString(ctx, "nom");
        CrateDef c = CrateService.crate(id);
        if (c == null) Msg.send(ctx.getSource(), "caisse.unknown", "crate", id);
        return c;
    }

    /** Conteneur vise (6 blocs). */
    private static class_2338 target(class_3222 p) {
        class_239 hit = p.method_5745(6.0, 1.0f, false);
        if (!(hit instanceof class_3965 bh) || hit.method_17783() != class_239.class_240.field_1332) return null;
        return bh.method_17777();
    }

    public static boolean isContainer(net.minecraft.class_1937 level, class_2338 pos) {
        class_2586 be = level.method_8321(pos);
        return be instanceof class_1263 || level.method_8320(pos).method_26204() instanceof class_2336;
    }

    private static int preview(CommandContext<class_2168> ctx) {
        class_3222 p = player(ctx);
        CrateDef c = crateArg(ctx);
        if (p == null || c == null) return 0;
        CrateService.preview(p, c.id, p.method_51469(), null);
        return 1;
    }

    private static int set(CommandContext<class_2168> ctx) {
        class_3222 p = player(ctx);
        CrateDef c = crateArg(ctx);
        if (p == null || c == null) return 0;
        class_2338 pos = target(p);
        if (pos == null || !isContainer(p.method_37908(), pos)) {
            Msg.send(p, "caisse.not_container");
            return 0;
        }
        String cur = Links.crateAt(p.method_37908(), pos);
        if (c.id.equals(cur)) {
            Msg.send(p, "caisse.already_linked", "crate", c.id);
            return 0;
        }
        Links.link(p.method_37908(), pos, c.id);
        Net.syncAllPositions();
        Msg.send(p, "caisse.linked", "crate", c.id, "x", pos.method_10263(), "y", pos.method_10264(), "z", pos.method_10260(), "world", Links.dim(p.method_37908()),
                "previous", cur == null ? "" : cur);
        Crates.LOG.info("[Crates] {} lie {} {} a la caisse {}", p.method_7334().getName(), Links.dim(p.method_37908()), pos.method_23854(), c.id);
        return 1;
    }

    private static int unset(CommandContext<class_2168> ctx, String name) {
        class_3222 p = ctx.getSource().method_44023();
        class_2338 pos = p == null ? null : target(p);
        String at = pos == null ? null : Links.crateAt(p.method_37908(), pos);
        if (at != null && (name == null || CrateDef.cleanId(name).equals(at))) {
            Links.unlink(Links.dim(p.method_37908()), pos);
            Net.syncAllPositions();
            Msg.send(ctx.getSource(), "caisse.unlinked", "crate", at);
            return 1;
        }
        if (name == null) {
            Msg.send(ctx.getSource(), "caisse.not_linked_any");
            return 0;
        }
        if (at != null) {
            Msg.send(ctx.getSource(), "caisse.other_crate", "other", at, "crate", name);
            return 0;
        }
        String id = CrateDef.cleanId(name);
        int n = Links.unlinkAll(id);
        Net.syncAllPositions();
        if (n == 0) {
            Msg.send(ctx.getSource(), "caisse.not_linked", "crate", id);
            return 0;
        }
        Msg.send(ctx.getSource(), "caisse.unlinked_all", "crate", id, "count", n);
        return n;
    }

    private static int editor(CommandContext<class_2168> ctx) {
        class_3222 p = player(ctx);
        if (p == null) return 0;
        if (!Net.openAdmin(p)) Msg.send(p, "general.no_client");
        return 1;
    }

    private static int toggle(CommandContext<class_2168> ctx) {
        CrateDef c = crateArg(ctx);
        if (c == null) return 0;
        c.maintenance = !c.maintenance;
        Cfg.saveCrate(c);
        Msg.send(ctx.getSource(), c.maintenance ? "caisse.toggled_on" : "caisse.toggled_off", "crate", c.id);
        return 1;
    }

    private static int toggleAll(CommandContext<class_2168> ctx) {
        Cfg.general.maintenanceGlobale = !Cfg.general.maintenanceGlobale;
        Cfg.saveGeneral();
        Msg.send(ctx.getSource(), Cfg.general.maintenanceGlobale ? "caisse.toggled_all_on" : "caisse.toggled_all_off");
        return 1;
    }

    /** Objet cle depuis un nom court (obsidienne...), un nom de caisse ou un identifiant d'objet. */
    public static class_1792 keyItem(String arg) {
        KeyType k = KeyType.byShortName(arg);
        if (k != null) return ModItems.KEYS.get(k);
        CrateDef c = CrateService.crate(arg);
        if (c != null) return CrateService.keyItem(c);
        return null;
    }

    private static int giveKey(CommandContext<class_2168> ctx, int amount) throws CommandSyntaxException {
        Collection<class_3222> targets = class_2186.method_9312(ctx, "joueur");
        String arg = StringArgumentType.getString(ctx, "cle");
        class_1792 key = keyItem(arg);
        if (key == null) {
            Msg.send(ctx.getSource(), "caisse.unknown_key", "key", arg);
            return 0;
        }
        String keyName = new class_1799(key).method_7964().getString();
        for (class_3222 t : targets) {
            Rewards.giveItem(t, new class_1799(key, amount));
            Msg.send(t, "caisse.givekey_received", "count", amount, "key", keyName);
            Msg.send(ctx.getSource(), "caisse.givekey", "count", amount, "key", keyName, "player", t.method_7334().getName());
        }
        return targets.size();
    }

    private static int giveWish(CommandContext<class_2168> ctx, int amount) throws CommandSyntaxException {
        Collection<class_3222> targets = class_2186.method_9312(ctx, "joueur");
        class_1792 wish = Reg.item(Cfg.builder.monnaie, ModItems.VOEU_ADN);
        for (class_3222 t : targets) {
            Rewards.giveItem(t, new class_1799(wish, amount));
            Msg.send(t, "builder.givewish_received", "count", amount);
            Msg.send(ctx.getSource(), "builder.givewish", "count", amount, "player", t.method_7334().getName());
        }
        return targets.size();
    }

    private static int reload(CommandContext<class_2168> ctx) {
        Net.reload();
        Msg.send(ctx.getSource(), "general.reloaded", "crates", Cfg.CRATES.size(), "pools", Cfg.POOLS.size(), "links", Links.all().size());
        return 1;
    }

    private static int list(CommandContext<class_2168> ctx) {
        Msg.send(ctx.getSource(), "caisse.list_header", "count", Cfg.CRATES.size(), "maint", Cfg.general.maintenanceGlobale ? " &c(maintenance globale)" : "");
        for (CrateDef c : Cfg.CRATES.values()) {
            List<Locations.Loc> locs = Links.forCrate(c.id);
            ctx.getSource().method_45068(TextUtil.legacy(Msg.format("caisse.list_entry", "crate", c.id, "name", c.nom, "rewards", c.recompenses.size(),
                    "links", locs.size(), "maint", c.maintenance ? " &c[maintenance]" : "")));
        }
        return 1;
    }
}

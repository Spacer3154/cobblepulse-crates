package fr.cobblepulse.crates.net;

import fr.cobblepulse.crates.Crates;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Deux paquets generiques (JSON) entre les ecrans (apercu, roulette, editeur, Voeu ADN) et le serveur. */
public final class Payloads {
    private static final class_9139<ByteBuf, String> BIG_STRING = class_9135.method_56364(1 << 22);

    private Payloads() {}

    private static <T extends class_8710> class_8710.class_9154<T> makeType(String path) {
        return new class_8710.class_9154<>(class_2960.method_60655(Crates.MOD_ID, path));
    }

    /** Client -> serveur : action et arguments JSON. */
    public record Action(String action, String json) implements class_8710 {
        public static final class_9154<Action> TYPE = makeType("action");
        public static final class_9139<ByteBuf, Action> CODEC = class_9139.method_56435(
                class_9135.field_48554, Action::action, BIG_STRING, Action::json, Action::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }

    /** Serveur -> client : donnees. */
    public record Data(String kind, String json) implements class_8710 {
        public static final class_9154<Data> TYPE = makeType("data");
        public static final class_9139<ByteBuf, Data> CODEC = class_9139.method_56435(
                class_9135.field_48554, Data::kind, BIG_STRING, Data::json, Data::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }
}

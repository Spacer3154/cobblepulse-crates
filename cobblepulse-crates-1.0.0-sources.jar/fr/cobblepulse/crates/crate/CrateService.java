package fr.cobblepulse.crates.crate;

import fr.cobblepulse.crates.Crates;
import fr.cobblepulse.crates.config.Cfg;
import fr.cobblepulse.crates.config.CrateDef;
import fr.cobblepulse.crates.config.GeneralConfig;
import fr.cobblepulse.crates.config.RewardDef;
import fr.cobblepulse.crates.core.Msg;
import fr.cobblepulse.crates.core.Perms;
import fr.cobblepulse.crates.core.Players;
import fr.cobblepulse.crates.core.Reg;
import fr.cobblepulse.crates.core.Scheduler;
import fr.cobblepulse.crates.core.TextUtil;
import fr.cobblepulse.crates.net.Net;
import fr.cobblepulse.crates.net.Views;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Apercu, ouverture (cle consommee, tirage pondere, animation), remise de la recompense et effets. */
public final class CrateService {
    /** Ouverture en cours : la recompense est donnee a la fin de l'animation (ou plus tot : passer, deconnexion, arret). */
    public static final class Opening {
        public final UUID player;
        public final String playerName;
        public final CrateDef crate;
        public final RewardDef reward;
        public final Rewards.Prepared prepared;
        public final class_5321<class_1937> dim;
        public final class_2338 pos;
        public final long endTick;
        boolean done;

        Opening(class_3222 p, CrateDef crate, RewardDef reward, Rewards.Prepared prepared, class_5321<class_1937> dim, class_2338 pos, long endTick) {
            this.player = p.method_5667();
            this.playerName = p.method_7334().getName();
            this.crate = crate;
            this.reward = reward;
            this.prepared = prepared;
            this.dim = dim;
            this.pos = pos;
            this.endTick = endTick;
        }
    }

    private static final Map<UUID, Opening> ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> LAST_CLICK = new HashMap<>();
    /** Auto-test : derniere recompense remise par joueur. */
    public static final Map<UUID, String> LAST_REWARD = new HashMap<>();

    private CrateService() {}

    public static CrateDef crate(String id) {
        return id == null ? null : Cfg.CRATES.get(CrateDef.cleanId(id));
    }

    public static boolean maintenance(CrateDef c) {
        return Cfg.general.maintenanceGlobale || c.maintenance;
    }

    public static boolean busy(class_3222 p) {
        Opening o = ACTIVE.get(p.method_5667());
        return o != null && !o.done;
    }

    // ------------------------------------------------------------------ Cles

    public static int countItem(class_3222 p, class_1792 item) {
        if (item == null) return 0;
        int n = 0;
        class_1661 inv = p.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(item)) n += s.method_7947();
        }
        return n;
    }

    /** Retire {@code n} objets de l'inventaire (tout ou rien). */
    public static boolean takeItem(class_3222 p, class_1792 item, int n) {
        if (countItem(p, item) < n) return false;
        int left = n;
        class_1661 inv = p.method_31548();
        for (int i = 0; i < inv.method_5439() && left > 0; i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_31574(item)) continue;
            int take = Math.min(left, s.method_7947());
            s.method_7934(take);
            if (s.method_7960()) inv.method_5447(i, class_1799.field_8037);
            left -= take;
        }
        inv.method_5431();
        p.field_7512.method_7623();
        return true;
    }

    public static class_1792 keyItem(CrateDef c) {
        return Reg.item(c.cle, null);
    }

    // ------------------------------------------------------------------ Tirage

    public static RewardDef roll(CrateDef c, Set<String> exclude) {
        double total = 0;
        for (RewardDef r : c.recompenses) if (r.poids > 0 && !exclude.contains(r.id)) total += r.poids;
        if (total <= 0) return null;
        double x = ThreadLocalRandom.current().nextDouble() * total;
        RewardDef last = null;
        for (RewardDef r : c.recompenses) {
            if (r.poids <= 0 || exclude.contains(r.id)) continue;
            last = r;
            x -= r.poids;
            if (x < 0) return r;
        }
        return last;
    }

    // ------------------------------------------------------------------ Apercu

    /** Clic (gauche ou droit) sur un conteneur lie : ouvre l'apercu. */
    public static void click(class_3222 p, class_3218 level, class_2338 pos, String crateId) {
        long now = Scheduler.currentTick();
        Long last = LAST_CLICK.get(p.method_5667());
        if (last != null && now - last < 8) return;
        LAST_CLICK.put(p.method_5667(), now);
        preview(p, crateId, level, pos);
    }

    public static void preview(class_3222 p, String crateId, class_3218 level, class_2338 pos) {
        CrateDef c = crate(crateId);
        if (c == null) {
            Msg.send(p, "caisse.unknown", "crate", crateId);
            return;
        }
        Net.send(p, "crate_preview", Views.preview(p, c, pos));
        if (!Net.hasClient(p)) Msg.send(p, "general.no_client");
    }

    // ------------------------------------------------------------------ Ouverture

    /**
     * Ouvre la caisse liee au conteneur {@code pos}.
     * @return null si l'ouverture a commence, sinon la cle du message d'erreur.
     */
    public static String open(class_3222 p, String crateId, class_2338 pos) {
        CrateDef c = crate(crateId);
        if (c == null) return fail(p, "caisse.unknown", "crate", crateId);
        if (busy(p)) return fail(p, "caisse.busy");
        if (pos == null || !c.id.equals(Links.crateAt(p.method_37908(), pos))) return fail(p, "caisse.remote");
        double d = Cfg.general.distanceMax;
        if (p.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > d * d) return fail(p, "caisse.too_far");
        if (!Perms.canOpen(p, c.id)) return fail(p, "caisse.no_open_perm");
        if (maintenance(c) && !Perms.bypassMaintenance(p)) {
            return fail(p, Cfg.general.maintenanceGlobale ? "caisse.maintenance_global" : "caisse.maintenance", "crate", TextUtil.strip(c.nom));
        }
        class_1792 key = keyItem(c);
        if (key == null) return fail(p, "caisse.bad_key", "key", c.cle);
        if (countItem(p, key) < c.clesRequises) {
            return fail(p, "caisse.no_key", "need", c.clesRequises, "key", new class_1799(key).method_7964().getString());
        }
        if (c.totalWeight() <= 0) return fail(p, "caisse.empty");
        // Tirage ; une recompense impossible a preparer (pool vide, objet invalide...) est retiree et on retire au sort
        Set<String> tried = new HashSet<>();
        List<String> errors = new ArrayList<>();
        RewardDef r = null;
        Rewards.Prepared prep = null;
        for (int attempt = 0; attempt < 8; attempt++) {
            r = roll(c, tried);
            if (r == null) break;
            List<String> errs = new ArrayList<>();
            prep = Rewards.prepare(r, errs);
            if (prep != null) break;
            errors.addAll(errs);
            Crates.LOG.warn("[Crates] Caisse {} : recompense {} ignoree ({})", c.id, r.id, String.join(", ", errs));
            tried.add(r.id);
            r = null;
        }
        if (prep == null) return fail(p, "caisse.error", "error", String.join(", ", errors));
        if (!takeItem(p, key, c.clesRequises)) return fail(p, "caisse.no_key", "need", c.clesRequises, "key", new class_1799(key).method_7964().getString());
        boolean instant = "instantanee".equals(c.animation);
        int ticks = instant ? 1 : (int) Math.round(c.dureeAnimation * 20) + 6;
        class_3218 level = p.method_51469();
        Opening o = new Opening(p, c, r, prep, level.method_27983(), pos.method_10062(), Scheduler.currentTick() + ticks);
        ACTIVE.put(p.method_5667(), o);
        Net.send(p, "crate_spin", Views.spin(p, c, r, prep, instant));
        WorldFx.openLid(level, pos, c);
        if (instant) complete(o, p);
        return null;
    }

    private static String fail(class_3222 p, String key, Object... kv) {
        Msg.send(p, key, kv);
        Net.toast(p, false, TextUtil.strip(Msg.format(key, kv)).replaceFirst("^.*» ", ""));
        return key;
    }

    public static void skip(class_3222 p) {
        Opening o = ACTIVE.get(p.method_5667());
        if (o != null && !o.done && o.crate.ouvertureRapide) complete(o, p);
    }

    public static void tick(MinecraftServer server) {
        long now = Scheduler.currentTick();
        if (!ACTIVE.isEmpty()) {
            for (Opening o : new ArrayList<>(ACTIVE.values())) {
                if (o.done) continue;
                if (now >= o.endTick) {
                    complete(o, Players.get(o.player));
                } else if (now % 3 == 0) {
                    class_2394 part = WorldFx.particle(o.crate.particuleOuverture);
                    if (part != null) WorldFx.spiral(server.method_3847(o.dim), o.pos, part, now);
                }
            }
        }
        WorldFx.idle(server, now);
    }

    /** Remise de la recompense et effets de fin. */
    static void complete(Opening o, class_3222 p) {
        if (o.done) return;
        o.done = true;
        ACTIVE.remove(o.player);
        MinecraftServer server = Crates.server();
        if (p == null) {
            Crates.LOG.error("[Crates] {} introuvable a la fin de l'ouverture de {} : recompense {} non remise", o.playerName, o.crate.id, o.reward.id);
            return;
        }
        try {
            o.prepared.give(p);
        } catch (Throwable t) {
            Crates.LOG.error("[Crates] Erreur en donnant {} ({}) a {}", o.reward.id, o.crate.id, o.playerName, t);
        }
        LAST_REWARD.put(o.player, o.crate.id + ":" + o.reward.id);
        GeneralConfig.Rarete rar = Cfg.general.rarity(o.reward.rarete);
        class_5250 name = class_2561.method_43473().method_27694(s -> s.method_36139(rar.color())).method_10852(o.prepared.name);
        class_3218 level = server == null ? null : server.method_3847(o.dim);
        if (level != null) {
            WorldFx.reveal(level, o.pos, rar);
            int holo = (int) Math.round(Cfg.general.hologramme.dureeSecondes * 20);
            if (o.crate.hologramme && Cfg.general.hologramme.actif) WorldFx.hologram(level, o.pos, o.prepared.icon, name, holo);
            WorldFx.closeLidLater(level, o.pos, o.crate.hologramme && Cfg.general.hologramme.actif ? holo : 30);
        }
        class_5250 hoverName = name.method_27661();
        if (!o.prepared.icon.method_7960()) {
            hoverName = hoverName.method_27694(s -> s.method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(o.prepared.icon))));
        }
        if (Msg.reachable(p)) p.method_43496(Msg.withComponent("caisse.won", "reward", hoverName, "crate", o.crate.nom));
        if (o.reward.annonce && Cfg.general.annonces) {
            Msg.broadcast(Msg.withComponent("caisse.announce", "reward", hoverName, "player", o.playerName, "crate", o.crate.nom));
        }
        OpenLog.log(o.playerName, o.crate.id, o.reward.id + " " + TextUtil.strip(o.prepared.name.getString()), rar.id, "");
        Net.send(p, "crate_done", Views.done(p, o.crate));
    }

    public static void onDisconnect(class_3222 p) {
        Opening o = ACTIVE.get(p.method_5667());
        if (o != null && !o.done) complete(o, p);
        LAST_CLICK.remove(p.method_5667());
    }

    /** Arret du serveur : toutes les ouvertures en cours sont terminees immediatement. */
    public static void shutdown() {
        for (Opening o : new ArrayList<>(ACTIVE.values())) {
            if (!o.done) complete(o, Players.get(o.player));
        }
        ACTIVE.clear();
        LAST_CLICK.clear();
    }

    public static int active() {
        return ACTIVE.size();
    }
}

package fr.cobblepulse.crates.crate;

import fr.cobblepulse.crates.Crates;
import fr.cobblepulse.crates.config.Cfg;
import fr.cobblepulse.crates.config.CrateDef;
import fr.cobblepulse.crates.config.GeneralConfig;
import fr.cobblepulse.crates.config.Locations;
import fr.cobblepulse.crates.core.Scheduler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_2480;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3708;
import net.minecraft.class_4590;
import net.minecraft.class_7923;
import net.minecraft.class_8104;
import net.minecraft.class_811;
import net.minecraft.class_8113;
import net.minecraft.server.MinecraftServer;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Effets dans le monde : couvercle du conteneur, hologramme temporaire, particules et sons. */
public final class WorldFx {
    public static final String HOLO_TAG = "cobblepulse_crates_holo";
    /** Hologrammes vivants (les autres, restes d'un arret brutal, sont supprimes au chargement). */
    private static final Set<UUID> LIVE_HOLOS = new HashSet<>();
    /** Nombre d'ouvertures en cours par conteneur (le couvercle reste ouvert tant qu'il y en a). */
    private static final Map<String, Integer> OPEN_LIDS = new HashMap<>();
    private static final Map<String, class_2394> PARTICLE_CACHE = new HashMap<>();

    private WorldFx() {}

    // ------------------------------------------------------------------ Particules et sons

    /** "minecraft:flame", "flame", "dust #FF8800 1.5" ; null si vide ou inconnu. */
    public static class_2394 particle(String spec) {
        if (spec == null || spec.isBlank()) return null;
        String s = spec.trim();
        if (PARTICLE_CACHE.containsKey(s)) return PARTICLE_CACHE.get(s);
        class_2394 out = null;
        try {
            String[] parts = s.split("\\s+");
            String id = parts[0].toLowerCase(Locale.ROOT);
            if ((id.equals("dust") || id.equals("minecraft:dust")) && parts.length >= 2) {
                int rgb = Integer.parseInt(parts[1].replace("#", ""), 16);
                float size = parts.length >= 3 ? Float.parseFloat(parts[2]) : 1.0f;
                out = new class_2390(new Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f),
                        Math.max(0.1f, Math.min(4f, size)));
            } else {
                class_2960 rl = class_2960.method_12829(id.contains(":") ? id : "minecraft:" + id);
                class_2396<?> t = rl == null ? null : class_7923.field_41180.method_10223(rl);
                if (t instanceof class_2400 simple) out = simple;
            }
        } catch (Exception ignored) {
        }
        if (out == null) Crates.LOG.warn("[Crates] Particule inconnue ou non prise en charge : {}", s);
        PARTICLE_CACHE.put(s, out);
        return out;
    }

    public static void clearCaches() {
        PARTICLE_CACHE.clear();
    }

    public static class_3414 sound(String id) {
        if (id == null || id.isBlank()) return null;
        class_2960 rl = class_2960.method_12829(id.trim().contains(":") ? id.trim() : "minecraft:" + id.trim());
        if (rl == null) return null;
        class_3414 e = class_7923.field_41172.method_10223(rl);
        // Son de pack de ressources (non enregistre) : joue tel quel
        return e != null ? e : class_3414.method_47908(rl);
    }

    public static void playSound(class_3218 level, class_2338 pos, String id, float volume, float pitch) {
        class_3414 s = sound(id);
        if (s != null && level != null) level.method_43128(null, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, s, class_3419.field_15245, volume, pitch);
    }

    public static void burst(class_3218 level, class_2338 pos, class_2394 p, int count, double spread, double speed) {
        if (level == null || p == null || count <= 0) return;
        level.method_14199(p, pos.method_10263() + 0.5, pos.method_10264() + 1.1, pos.method_10260() + 0.5, count, spread, spread * 0.6, spread, speed);
    }

    /** Spirale de particules pendant l'animation. */
    public static void spiral(class_3218 level, class_2338 pos, class_2394 p, long tick) {
        if (level == null || p == null) return;
        for (int i = 0; i < 2; i++) {
            double a = (tick * 0.45) + i * Math.PI;
            double r = 0.75;
            double y = pos.method_10264() + 0.3 + ((tick % 20) / 20.0) * 1.2;
            level.method_14199(p, pos.method_10263() + 0.5 + Math.cos(a) * r, y, pos.method_10260() + 0.5 + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    /** Particules d'ambiance autour des caisses proches des joueurs. */
    public static void idle(MinecraftServer server, long tick) {
        GeneralConfig.Particules cfg = Cfg.general.particules;
        if (!cfg.ambiance || tick % cfg.intervalleTicks != 0) return;
        double r2 = cfg.rayonJoueurs * cfg.rayonJoueurs;
        for (Locations.Loc l : Links.all()) {
            CrateDef c = Cfg.CRATES.get(l.caisse);
            if (c == null || c.particuleAttente.isBlank()) continue;
            class_2960 dim = class_2960.method_12829(l.monde);
            if (dim == null) continue;
            class_3218 level = null;
            for (class_3218 lv : server.method_3738()) {
                if (lv.method_27983().method_29177().equals(dim)) {
                    level = lv;
                    break;
                }
            }
            if (level == null || !level.method_8477(new class_2338(l.x, l.y, l.z))) continue;
            boolean near = false;
            for (class_3222 p : level.method_18456()) {
                if (p.method_5649(l.x + 0.5, l.y + 0.5, l.z + 0.5) <= r2) {
                    near = true;
                    break;
                }
            }
            if (!near) continue;
            class_2394 p = particle(c.particuleAttente);
            if (p == null) continue;
            double a = (tick / (double) cfg.intervalleTicks) * 0.9;
            level.method_14199(p, l.x + 0.5 + Math.cos(a) * 0.6, l.y + 1.05, l.z + 0.5 + Math.sin(a) * 0.6, 1, 0.05, 0.1, 0.05, 0.0);
        }
    }

    // ------------------------------------------------------------------ Couvercle

    private static String lidKey(class_3218 level, class_2338 pos) {
        return Links.dim(level) + "|" + pos.method_10063();
    }

    public static void openLid(class_3218 level, class_2338 pos, CrateDef crate) {
        if (level == null || pos == null) return;
        String k = lidKey(level, pos);
        int n = OPEN_LIDS.getOrDefault(k, 0);
        OPEN_LIDS.put(k, n + 1);
        class_2680 st = level.method_8320(pos);
        if (n == 0) setLid(level, pos, st, true);
        if (!crate.sonOuverture.isBlank()) playSound(level, pos, crate.sonOuverture, 0.9f, 1.0f);
        else {
            class_3414 s = containerSound(st.method_26204(), true);
            if (s != null) level.method_8396(null, pos, s, class_3419.field_15245, 0.6f, 0.95f);
        }
    }

    public static void closeLidLater(class_3218 level, class_2338 pos, int delayTicks) {
        if (level == null || pos == null) return;
        String k = lidKey(level, pos);
        Scheduler.later(Math.max(1, delayTicks), () -> {
            int n = OPEN_LIDS.getOrDefault(k, 1) - 1;
            if (n > 0) {
                OPEN_LIDS.put(k, n);
                return;
            }
            OPEN_LIDS.remove(k);
            if (!level.method_8477(pos)) return;
            class_2680 st = level.method_8320(pos);
            setLid(level, pos, st, false);
            class_3414 s = containerSound(st.method_26204(), false);
            if (s != null) level.method_8396(null, pos, s, class_3419.field_15245, 0.5f, 1.0f);
        });
    }

    private static void setLid(class_3218 level, class_2338 pos, class_2680 st, boolean open) {
        class_2248 b = st.method_26204();
        try {
            if (st.method_28498(class_2741.field_12537)) {
                level.method_8652(pos, st.method_11657(class_2741.field_12537, open), class_2248.field_31036);
            } else if (b instanceof class_2281 || b instanceof class_2336 || b instanceof class_2480) {
                level.method_8427(pos, b, 1, open ? 1 : 0);
            }
        } catch (Throwable t) {
            Crates.LOG.debug("[Crates] Couvercle : {}", t.toString());
        }
    }

    private static class_3414 containerSound(class_2248 b, boolean open) {
        if (b instanceof class_3708) return open ? class_3417.field_17604 : class_3417.field_17603;
        if (b instanceof class_2336) return open ? class_3417.field_14952 : class_3417.field_15206;
        if (b instanceof class_2480) return open ? class_3417.field_14825 : class_3417.field_14751;
        if (b instanceof class_2281) return open ? class_3417.field_14982 : class_3417.field_14823;
        return null;
    }

    // ------------------------------------------------------------------ Hologramme

    /** Objet tournant + nom de la recompense au-dessus de la caisse, retires apres la duree configuree. */
    public static void hologram(class_3218 level, class_2338 pos, class_1799 icon, class_2561 name, int durationTicks) {
        if (level == null || pos == null) return;
        GeneralConfig.Hologramme h = Cfg.general.hologramme;
        double y = pos.method_10264() + h.hauteur;
        try {
            class_8113.class_8122 item = new class_8113.class_8122(class_1299.field_42456, level);
            item.method_5814(pos.method_10263() + 0.5, y + 0.25, pos.method_10260() + 0.5);
            item.method_48897(icon.method_46651(1));
            item.method_48896(class_811.field_4318);
            item.method_48847(class_8113.class_8114.field_42407);
            float s = (float) h.echelleObjet * 1.6f;
            item.method_48849(new class_4590(new Vector3f(0, 0, 0), new Quaternionf(), new Vector3f(s, s, s), new Quaternionf()));
            item.method_48846(new class_8104(15, 15));
            item.method_48861(0.6f);
            item.method_5780(HOLO_TAG);
            class_8113.class_8123 text = new class_8113.class_8123(class_1299.field_42457, level);
            text.method_5814(pos.method_10263() + 0.5, y - 0.05, pos.method_10260() + 0.5);
            text.method_48911(name);
            text.method_48847(class_8113.class_8114.field_42409);
            text.method_48910(0x80101018);
            text.method_48908(220);
            text.method_48912(class_8113.class_8123.field_42444);
            text.method_48861(0.6f);
            text.method_5780(HOLO_TAG);
            LIVE_HOLOS.add(item.method_5667());
            LIVE_HOLOS.add(text.method_5667());
            level.method_8649(item);
            level.method_8649(text);
            // Petite montee + rotation douce (interpolee cote client)
            Scheduler.later(2, () -> {
                if (item.method_31481()) return;
                item.method_52525(0);
                item.method_52524(Math.max(10, durationTicks - 4));
                item.method_48849(new class_4590(new Vector3f(0, 0.25f, 0), new Quaternionf().rotateY((float) Math.PI * 2f - 0.01f),
                        new Vector3f(s, s, s), new Quaternionf()));
            });
            Scheduler.later(Math.max(10, durationTicks), () -> {
                remove(item);
                remove(text);
            });
        } catch (Throwable t) {
            Crates.LOG.warn("[Crates] Hologramme impossible : {}", t.toString());
        }
    }

    private static void remove(class_1297 e) {
        LIVE_HOLOS.remove(e.method_5667());
        if (!e.method_31481()) e.method_31472();
    }

    /** Entite chargee : un hologramme orphelin (arret du serveur pendant l'affichage) est supprime. */
    public static void onEntityLoad(class_1297 e) {
        if (e instanceof class_8113 && e.method_5752().contains(HOLO_TAG) && !LIVE_HOLOS.contains(e.method_5667())) e.method_31472();
    }

    public static int liveHolograms() {
        return LIVE_HOLOS.size();
    }

    public static void clear() {
        LIVE_HOLOS.clear();
        OPEN_LIDS.clear();
        PARTICLE_CACHE.clear();
    }

    /** Recompense obtenue : particules et son de la rarete. */
    public static void reveal(class_3218 level, class_2338 pos, GeneralConfig.Rarete rarity) {
        if (level == null || pos == null) return;
        burst(level, pos, particle(rarity.particule), rarity.quantite, 0.45, 0.08);
        playSound(level, pos, rarity.son, (float) rarity.volume, (float) rarity.tonalite);
    }

    public static List<String> knownParticleExamples() {
        return List.of("minecraft:flame", "minecraft:end_rod", "minecraft:totem_of_undying", "dust #FFD24A 1.2");
    }
}

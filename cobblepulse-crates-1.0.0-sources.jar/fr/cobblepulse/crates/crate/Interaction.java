package fr.cobblepulse.crates.crate;

import fr.cobblepulse.crates.core.Msg;
import fr.cobblepulse.crates.core.TextUtil;
import fr.cobblepulse.crates.config.CrateDef;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** Clic gauche / clic droit sur un conteneur lie = meme ecran d'apercu ; conteneur protege contre la casse. */
public final class Interaction {
    private Interaction() {}

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            class_2338 pos = hit.method_17777();
            if (world.field_9236) return Links.CLIENT_POSITIONS.contains(pos.method_10063()) ? class_1269.field_5812 : class_1269.field_5811;
            String crate = Links.crateAt(world, pos);
            if (crate == null) return class_1269.field_5811;
            if (hand == class_1268.field_5808 && player instanceof class_3222 sp && world instanceof class_3218 sl) {
                CrateService.click(sp, sl, pos, crate);
            }
            return class_1269.field_5812;
        });
        AttackBlockCallback.EVENT.register((player, world, hand, pos, dir) -> {
            if (world.field_9236) return Links.CLIENT_POSITIONS.contains(pos.method_10063()) ? class_1269.field_5812 : class_1269.field_5811;
            String crate = Links.crateAt(world, pos);
            if (crate == null) return class_1269.field_5811;
            if (player instanceof class_3222 sp && world instanceof class_3218 sl) CrateService.click(sp, sl, pos, crate);
            return class_1269.field_5812;
        });
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> {
            String crate = Links.crateAt(world, pos);
            if (crate == null) return true;
            if (player instanceof class_3222 sp) {
                CrateDef c = CrateService.crate(crate);
                Msg.send(sp, "caisse.protected", "crate", crate, "name", c == null ? crate : TextUtil.strip(c.nom));
            }
            return false;
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> WorldFx.onEntityLoad(entity));
    }
}

package fr.cobblepulse.crates.crate;

import fr.cobblepulse.crates.config.Cfg;
import fr.cobblepulse.crates.config.Locations;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5321;

/** Index des conteneurs lies aux caisses (multi-mondes). */
public final class Links {
    private static final Map<String, Locations.Loc> BY_KEY = new HashMap<>();
    private static int builtFor = -1;

    private Links() {}

    public static String dim(class_1937 level) {
        return level.method_27983().method_29177().toString();
    }

    public static String dim(class_5321<class_1937> key) {
        return key.method_29177().toString();
    }

    private static void ensure() {
        if (builtFor != Cfg.revision) rebuild();
    }

    public static void rebuild() {
        BY_KEY.clear();
        for (Locations.Loc l : Cfg.locations.emplacements) BY_KEY.put(l.key(), l);
        builtFor = Cfg.revision;
    }

    /** Caisse liee a ce bloc (null si aucune). */
    public static String crateAt(class_1937 level, class_2338 pos) {
        ensure();
        Locations.Loc l = BY_KEY.get(Locations.Loc.key(dim(level), pos.method_10263(), pos.method_10264(), pos.method_10260()));
        return l == null ? null : l.caisse;
    }

    public static String crateAt(String dim, class_2338 pos) {
        ensure();
        Locations.Loc l = BY_KEY.get(Locations.Loc.key(dim, pos.method_10263(), pos.method_10264(), pos.method_10260()));
        return l == null ? null : l.caisse;
    }

    public static void link(class_1937 level, class_2338 pos, String crate) {
        ensure();
        unlinkRaw(dim(level), pos);
        Locations.Loc l = new Locations.Loc(dim(level), pos.method_10263(), pos.method_10264(), pos.method_10260(), crate);
        Cfg.locations.emplacements.add(l);
        Cfg.saveLocations();
        rebuild();
    }

    private static boolean unlinkRaw(String dim, class_2338 pos) {
        return Cfg.locations.emplacements.removeIf(l -> l.monde.equals(dim) && l.x == pos.method_10263() && l.y == pos.method_10264() && l.z == pos.method_10260());
    }

    public static boolean unlink(String dim, class_2338 pos) {
        boolean r = unlinkRaw(dim, pos);
        if (r) {
            Cfg.saveLocations();
            rebuild();
        }
        return r;
    }

    /** Delie tous les conteneurs d'une caisse ; renvoie le nombre. */
    public static int unlinkAll(String crate) {
        int before = Cfg.locations.emplacements.size();
        Cfg.locations.emplacements.removeIf(l -> l.caisse.equalsIgnoreCase(crate));
        int n = before - Cfg.locations.emplacements.size();
        if (n > 0) {
            Cfg.saveLocations();
            rebuild();
        }
        return n;
    }

    public static List<Locations.Loc> forCrate(String crate) {
        List<Locations.Loc> out = new ArrayList<>();
        for (Locations.Loc l : Cfg.locations.emplacements) if (l.caisse.equalsIgnoreCase(crate)) out.add(l);
        return out;
    }

    public static List<Locations.Loc> inDimension(String dim) {
        List<Locations.Loc> out = new ArrayList<>();
        for (Locations.Loc l : Cfg.locations.emplacements) if (l.monde.equals(dim)) out.add(l);
        return out;
    }

    public static List<Locations.Loc> all() {
        return Cfg.locations.emplacements;
    }

    /** Positions connues du client (mises a jour par le reseau) : annulent le minage et l'usage cote client. */
    public static final java.util.Set<Long> CLIENT_POSITIONS = java.util.concurrent.ConcurrentHashMap.newKeySet();
}

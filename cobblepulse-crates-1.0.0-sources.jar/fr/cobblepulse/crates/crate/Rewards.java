package fr.cobblepulse.crates.crate;

import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.pokemon.PokemonProperties;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.item.PokemonItem;
import com.cobblemon.mod.common.pokemon.FormData;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.cobblemon.mod.common.pokemon.Species;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import fr.cobblepulse.crates.Crates;
import fr.cobblepulse.crates.config.Cfg;
import fr.cobblepulse.crates.config.GeneralConfig;
import fr.cobblepulse.crates.config.PoolDef;
import fr.cobblepulse.crates.config.RewardDef;
import fr.cobblepulse.crates.core.Json;
import fr.cobblepulse.crates.core.Reg;
import fr.cobblepulse.crates.core.TextUtil;
import fr.cobblepulse.crates.pokemon.FormTools;
import fr.cobblepulse.crates.pokemon.MonSpec;
import fr.cobblepulse.crates.pokemon.Names;
import fr.cobblepulse.crates.pokemon.PokemonFactory;
import fr.cobblepulse.crates.pokemon.SpeciesLookup;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/** Affichage (icone, nom, details) et distribution des recompenses. */
public final class Rewards {
    private static final Map<String, class_1799> ICON_CACHE = new HashMap<>();
    private static int cacheRevision = -1;
    private static final Stats[] STATS = {Stats.HP, Stats.ATTACK, Stats.DEFENCE, Stats.SPECIAL_ATTACK, Stats.SPECIAL_DEFENCE, Stats.SPEED};

    private Rewards() {}

    public static class_7225.class_7874 regs() {
        MinecraftServer s = Crates.server();
        return s == null ? null : s.method_30611();
    }

    // ------------------------------------------------------------------ Objets (JSON de Minecraft)

    /** Objet decrit en JSON ({"id", "count", "components"}) ; la quantite peut depasser 99. */
    public static class_1799 decodeItem(JsonElement json) {
        class_7225.class_7874 regs = regs();
        if (json == null || json.isJsonNull() || regs == null) return class_1799.field_8037;
        try {
            int count = 1;
            JsonElement parse = json;
            if (json.isJsonObject()) {
                JsonObject o = json.getAsJsonObject().deepCopy();
                if (o.has("count")) count = Math.max(1, o.get("count").getAsInt());
                o.addProperty("count", 1);
                parse = o;
            } else if (json.isJsonPrimitive()) {
                JsonObject o = new JsonObject();
                o.addProperty("id", json.getAsString());
                o.addProperty("count", 1);
                parse = o;
            }
            class_1799 s = class_1799.field_24671.parse(class_6903.method_46632(JsonOps.INSTANCE, regs), parse).result().orElse(class_1799.field_8037);
            if (!s.method_7960()) s.method_7939(count);
            return s;
        } catch (Exception e) {
            return class_1799.field_8037;
        }
    }

    public static JsonElement encodeItem(class_1799 stack) {
        class_7225.class_7874 regs = regs();
        if (stack == null || stack.method_7960() || regs == null) return null;
        int count = stack.method_7947();
        JsonElement e = class_1799.field_24671.encodeStart(class_6903.method_46632(JsonOps.INSTANCE, regs), stack.method_46651(1)).result().orElse(null);
        if (e != null && e.isJsonObject()) e.getAsJsonObject().addProperty("count", count);
        return e;
    }

    /** Donne l'objet (en plusieurs piles si besoin) ; le surplus tombe aux pieds du joueur. */
    public static void giveItem(class_3222 p, class_1799 stack) {
        int left = stack.method_7947();
        int max = Math.max(1, stack.method_7914());
        while (left > 0) {
            int n = Math.min(max, left);
            class_1799 part = stack.method_46651(n);
            p.method_31548().method_7394(part);
            if (!part.method_7960()) p.method_7328(part, false);
            left -= n;
        }
        p.field_7512.method_7623();
    }

    public static void givePokemon(class_3222 p, Pokemon pk) {
        PlayerPartyStore party = Cobblemon.INSTANCE.getStorage().getParty(p);
        if (!party.add(pk)) Cobblemon.INSTANCE.getStorage().getPC(p).add(pk);
    }

    public static void runCommands(MinecraftServer server, List<String> commands, class_3222 p) {
        if (server == null) return;
        String name = p.method_7334().getName();
        String uuid = p.method_5667().toString();
        for (String c : commands) {
            String cmd = c.trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            cmd = cmd.replace("%player%", name).replace("%joueur%", name).replace("%uuid%", uuid);
            try {
                server.method_3734().method_44252(server.method_3739().method_9217(), cmd);
            } catch (Throwable t) {
                Crates.LOG.warn("[Crates] Commande de recompense en echec '{}' : {}", cmd, t.toString());
            }
        }
    }

    // ------------------------------------------------------------------ Pokemon aleatoire

    /** Tire un Pokemon dans le pool de la recompense (niveau, chromatique, IV parfaits, forme). */
    public static Pokemon rollPokemon(RewardDef.RandomMon a, List<String> errors) {
        a.normalize();
        List<Species> list = Pools.species(a.pool);
        if (list.isEmpty()) {
            PoolDef def = Cfg.POOLS.get(a.pool);
            errors.add(def == null ? "pool inconnu : " + a.pool : "pool vide : " + a.pool);
            return null;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        Species sp = list.get(rnd.nextInt(list.size()));
        int level = a.niveauMin + rnd.nextInt(a.niveauMax - a.niveauMin + 1);
        boolean shiny = a.chanceShiny > 0 && rnd.nextDouble() * 100.0 < a.chanceShiny;
        Pokemon pk;
        try {
            PokemonProperties pp = PokemonProperties.Companion.parse("level=" + level + " shiny=" + (shiny ? "yes" : "no"));
            pp.setSpecies(sp.getResourceIdentifier().toString());
            pk = pp.create();
            if (pk.getSpecies() != sp) pk.setSpecies(sp);
        } catch (Throwable t) {
            errors.add("création impossible (" + sp.getName() + ") : " + t.getMessage());
            return null;
        }
        if ("aleatoire".equals(a.formes)) {
            List<FormData> forms = FormTools.allowed(sp);
            if (forms.size() > 1) {
                FormData f = forms.get(rnd.nextInt(forms.size()));
                if (!FormTools.isStandard(sp, f)) FormTools.apply(pk, f);
            }
        }
        List<Stats> order = new ArrayList<>(List.of(STATS));
        Collections.shuffle(order);
        for (int i = 0; i < a.ivsParfaits; i++) pk.setIV(order.get(i), 31);
        pk.setShiny(shiny);
        pk.heal();
        return pk;
    }

    // ------------------------------------------------------------------ Distribution

    /** Recompense prete a etre donnee (preparee a l'ouverture pour connaitre le resultat exact). */
    public static final class Prepared {
        public final class_1799 icon;
        public final class_5250 name;
        private final java.util.function.Consumer<class_3222> giver;

        Prepared(class_1799 icon, class_5250 name, java.util.function.Consumer<class_3222> giver) {
            this.icon = icon;
            this.name = name;
            this.giver = giver;
        }

        public void give(class_3222 p) {
            giver.accept(p);
        }
    }

    /** Prepare la recompense ; null (et une erreur) si elle ne peut pas etre donnee. */
    public static Prepared prepare(RewardDef r, List<String> errors) {
        r.normalize();
        switch (r.type()) {
            case "objet" -> {
                class_1799 s = decodeItem(r.objet);
                if (s.method_7960()) {
                    errors.add("objet invalide (" + (r.objet == null ? "vide" : r.objet.toString()) + ")");
                    return null;
                }
                return new Prepared(s.method_7972(), name(r), p -> giveItem(p, s.method_7972()));
            }
            case "commande" -> {
                if (r.commandes.isEmpty()) {
                    errors.add("aucune commande");
                    return null;
                }
                List<String> cmds = new ArrayList<>(r.commandes);
                return new Prepared(icon(r), name(r), p -> runCommands(p.method_5682(), cmds, p));
            }
            case "pokemon" -> {
                List<String> errs = new ArrayList<>();
                Pokemon pk = PokemonFactory.create(Json.copy(r.pokemon, MonSpec.class), errs);
                if (pk == null) {
                    errors.addAll(errs);
                    return null;
                }
                if (!errs.isEmpty()) Crates.LOG.warn("[Crates] Recompense Pokemon {} : {}", r.pokemon.species, String.join(" | ", errs));
                return new Prepared(PokemonItem.from(pk), name(r), p -> givePokemon(p, pk));
            }
            case "pokemon_aleatoire" -> {
                Pokemon pk = rollPokemon(r.aleatoire, errors);
                if (pk == null) return null;
                return new Prepared(PokemonItem.from(pk), pokemonName(pk), p -> givePokemon(p, pk));
            }
            default -> {
                errors.add("type inconnu " + r.type);
                return null;
            }
        }
    }

    // ------------------------------------------------------------------ Affichage

    public static void clearCaches() {
        ICON_CACHE.clear();
    }

    /** Icone de la recompense dans l'apercu (Poke Ball pour un Pokemon aleatoire). */
    public static class_1799 icon(RewardDef r) {
        if (cacheRevision != Cfg.revision) {
            ICON_CACHE.clear();
            cacheRevision = Cfg.revision;
        }
        r.normalize();
        switch (r.type()) {
            case "objet" -> {
                class_1799 s = decodeItem(r.objet);
                if (!r.icone.isBlank()) {
                    class_1799 i = Reg.stack(r.icone);
                    i.method_7939(Math.max(1, Math.min(99, s.method_7947())));
                    return i;
                }
                if (s.method_7960()) return new class_1799(class_1802.field_8077);
                class_1799 d = s.method_7972();
                d.method_7939(Math.max(1, Math.min(99, s.method_7947())));
                return d;
            }
            case "pokemon" -> {
                if (!r.icone.isBlank()) return Reg.stack(r.icone);
                String key = Json.COMPACT.toJson(r.pokemon);
                class_1799 cached = ICON_CACHE.get(key);
                if (cached != null) return cached.method_7972();
                class_1799 out;
                try {
                    Pokemon pk = PokemonFactory.create(Json.copy(r.pokemon, MonSpec.class), new ArrayList<>());
                    out = pk == null ? new class_1799(class_1802.field_8077) : PokemonItem.from(pk);
                } catch (Throwable t) {
                    out = new class_1799(class_1802.field_8077);
                }
                ICON_CACHE.put(key, out.method_7972());
                return out;
            }
            case "pokemon_aleatoire" -> {
                return Reg.stack(r.icone.isBlank() ? "cobblemon:poke_ball" : r.icone);
            }
            default -> {
                return Reg.stack(r.icone.isBlank() ? "minecraft:paper" : r.icone);
            }
        }
    }

    public static class_5250 pokemonName(Pokemon pk) {
        class_5250 c = class_2561.method_43473().method_10852(pk.getSpecies().getTranslatedName());
        if (!FormTools.isStandard(pk.getSpecies(), pk.getForm())) c.method_10852(class_2561.method_43470(" (" + FormTools.label(pk.getSpecies(), pk.getForm()) + ")"));
        c.method_10852(class_2561.method_43470(" Nv. " + pk.getLevel()));
        if (pk.getShiny()) c.method_10852(class_2561.method_43470(" ★").method_27692(class_124.field_1065));
        return c;
    }

    /** Nom affiche (sans couleur de rarete). */
    public static class_5250 name(RewardDef r) {
        if (!r.nom.isBlank()) return TextUtil.legacy(r.nom);
        switch (r.type()) {
            case "objet" -> {
                class_1799 s = decodeItem(r.objet);
                if (s.method_7960()) return class_2561.method_43470("Objet invalide").method_27692(class_124.field_1061);
                class_5250 c = class_2561.method_43473().method_10852(s.method_7964());
                return s.method_7947() > 1 ? c.method_10852(class_2561.method_43470(" ×" + s.method_7947())) : c;
            }
            case "pokemon" -> {
                MonSpec m = r.pokemon;
                class_5250 c = class_2561.method_43473();
                Species sp = SpeciesLookup.resolve(m.species);
                c.method_10852(sp == null ? class_2561.method_43470(m.species) : sp.getTranslatedName());
                c.method_10852(class_2561.method_43470(" Nv. " + m.level));
                if (m.shiny) c.method_10852(class_2561.method_43470(" ★").method_27692(class_124.field_1065));
                return c;
            }
            case "pokemon_aleatoire" -> {
                PoolDef p = Cfg.POOLS.get(r.aleatoire.pool);
                return class_2561.method_43470("Pokémon aléatoire" + (p == null ? "" : " — " + TextUtil.strip(p.nom)));
            }
            default -> {
                return class_2561.method_43470("Récompense spéciale");
            }
        }
    }

    /** Nom colore selon la rarete. */
    public static class_5250 coloredName(RewardDef r, class_5250 base) {
        GeneralConfig.Rarete rar = Cfg.general.rarity(r.rarete);
        if (!r.nom.isBlank()) return base;
        return class_2561.method_43473().method_27694(s -> s.method_36139(rar.color())).method_10852(base);
    }

    public static String percent(double chance) {
        double pct = chance * 100.0;
        String s;
        if (pct >= 10) s = String.format(Locale.FRANCE, "%.1f", pct);
        else if (pct >= 1) s = String.format(Locale.FRANCE, "%.2f", pct);
        else s = String.format(Locale.FRANCE, "%.3f", pct);
        if (s.contains(",")) s = s.replaceAll("0+$", "").replaceAll(",$", "");
        return s + " %";
    }

    /** Details (infobulle). */
    public static List<class_5250> lore(RewardDef r) {
        List<class_5250> out = new ArrayList<>();
        for (String d : r.description) out.add(TextUtil.legacy(d));
        switch (r.type()) {
            case "pokemon" -> {
                MonSpec m = r.pokemon;
                if (m.shiny) out.add(class_2561.method_43470("Chromatique").method_27692(class_124.field_1065));
                if (!m.form.isBlank()) out.add(class_2561.method_43470("Forme : " + m.form).method_27692(class_124.field_1080));
                if (!m.nature.isBlank()) out.add(class_2561.method_43470("Nature : " + Names.nature(m.nature)).method_27692(class_124.field_1080));
                if (!m.ability.isBlank()) out.add(class_2561.method_43470("Talent : " + m.ability).method_27692(class_124.field_1080));
                StringBuilder iv = new StringBuilder();
                boolean anyIv = false;
                for (String s : MonSpec.STATS) {
                    int v = m.iv(s);
                    if (v >= 0) anyIv = true;
                    iv.append(iv.length() == 0 ? "" : " / ").append(v < 0 ? "?" : String.valueOf(v));
                }
                if (anyIv) out.add(class_2561.method_43470("IV : " + iv).method_27692(class_124.field_1075));
                if (!m.heldItem.isBlank()) out.add(class_2561.method_43470("Objet tenu : " + m.heldItem).method_27692(class_124.field_1080));
            }
            case "pokemon_aleatoire" -> {
                RewardDef.RandomMon a = r.aleatoire;
                PoolDef p = Cfg.POOLS.get(a.pool);
                out.add(class_2561.method_43470("Pool : " + (p == null ? a.pool : TextUtil.strip(p.nom)) + " (" + Pools.species(a.pool).size() + " espèces)")
                        .method_27692(class_124.field_1080));
                out.add(class_2561.method_43470("Niveau " + (a.niveauMin == a.niveauMax ? String.valueOf(a.niveauMin) : a.niveauMin + " à " + a.niveauMax))
                        .method_27692(class_124.field_1080));
                if (a.chanceShiny > 0) out.add(class_2561.method_43470("Chromatique : " + percent(a.chanceShiny / 100.0)).method_27692(class_124.field_1065));
                if (a.ivsParfaits > 0) out.add(class_2561.method_43470(a.ivsParfaits + " IV parfait" + (a.ivsParfaits > 1 ? "s" : "") + " garanti"
                        + (a.ivsParfaits > 1 ? "s" : "")).method_27692(class_124.field_1075));
                if ("aleatoire".equals(a.formes)) out.add(class_2561.method_43470("Formes régionales / variantes possibles").method_27692(class_124.field_1080));
            }
            default -> {
            }
        }
        return out;
    }
}

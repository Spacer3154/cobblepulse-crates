package fr.cobblepulse.crates.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.cobblepulse.crates.Crates;
import fr.cobblepulse.crates.crate.Links;
import fr.cobblepulse.crates.net.Payloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Cote client : ecrans des caisses, editeur, menu Voeu ADN (touche N) et positions des caisses. */
public final class CratesClient implements ClientModInitializer {
    private static class_304 builderKey;

    @Override
    public void onInitializeClient() {
        builderKey = KeyBindingHelper.registerKeyBinding(new class_304("key.cobblepulse_crates.builder", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_N, "key.categories.cobblepulse_crates"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (builderKey.method_1436()) {
                if (mc.field_1724 != null && mc.field_1755 == null) Ui.send("builder_open");
            }
        });
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Data.TYPE, (payload, ctx) -> ctx.client().execute(() -> receive(payload.kind(), payload.json())));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> Links.CLIENT_POSITIONS.clear());
        if ("true".equals(System.getProperty("cobblepulse_crates.clienttest"))) ClientSelfTest.install();
        if ("true".equals(System.getProperty("cobblepulse_crates.livetest"))) ClientSelfTest.installLive();
        Crates.LOG.info("[Crates] Client initialise");
    }

    static void receive(String kind, String json) {
        class_310 mc = class_310.method_1551();
        JsonObject o;
        try {
            o = JsonParser.parseString(json).getAsJsonObject();
        } catch (Exception e) {
            Crates.LOG.warn("[Crates] Donnees illisibles ({}) : {}", kind, e.toString());
            return;
        }
        switch (kind) {
            case "positions" -> {
                Links.CLIENT_POSITIONS.clear();
                for (JsonElement e : Ui.arr(o, "pos")) Links.CLIENT_POSITIONS.add(e.getAsLong());
            }
            case "crate_preview" -> {
                if (mc.field_1755 instanceof CrateScreen s && s.crateId().equals(Ui.str(o, "id", ""))) s.showPreview(o);
                else {
                    Ui.clearCaches();
                    mc.method_1507(new CrateScreen(o));
                }
            }
            case "crate_spin" -> {
                if (mc.field_1755 instanceof CrateScreen s) s.startSpin(o);
                else {
                    CrateScreen s = new CrateScreen(o);
                    mc.method_1507(s);
                    s.startSpin(o);
                }
            }
            case "crate_done" -> {
                if (mc.field_1755 instanceof CrateScreen s) s.onDone(o);
            }
            case "toast" -> {
                boolean ok = Ui.bool(o, "ok", false);
                String msg = Ui.str(o, "message", "");
                if (mc.field_1755 instanceof Toaster t) t.toast(ok, msg);
                else if (mc.field_1755 instanceof EditScreen e && e.parent instanceof Toaster t) t.toast(ok, msg);
                else if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470(msg), true);
            }
            case "admin_open" -> mc.method_1507(new AdminScreen(o));
            case "admin_data" -> {
                if (mc.field_1755 instanceof AdminScreen s) s.refreshData(o);
                else if (mc.field_1755 instanceof EditScreen e && e.parent instanceof AdminScreen s) s.refreshData(o);
            }
            case "admin_result" -> {
                if (mc.field_1755 instanceof AdminScreen s) s.onResult(o);
            }
            case "pokemon_check" -> {
                if (mc.field_1755 instanceof RewardEditScreen s) s.onCheck(o);
            }
            case "builder_open" -> mc.method_1507(new BuilderScreen(o));
            case "builder_data" -> {
                if (mc.field_1755 instanceof BuilderScreen s) s.refresh(o);
            }
            case "builder_box" -> {
                if (mc.field_1755 instanceof BuilderScreen s) s.onBox(o);
            }
            case "builder_result" -> {
                if (mc.field_1755 instanceof BuilderScreen s) s.onResult(o);
            }
            default -> {
            }
        }
    }

    /** Ecran capable d'afficher une notification. */
    public interface Toaster {
        void toast(boolean ok, String message);
    }
}

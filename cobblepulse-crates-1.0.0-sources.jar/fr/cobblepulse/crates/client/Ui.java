package fr.cobblepulse.crates.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import fr.cobblepulse.crates.core.ItemSerial;
import fr.cobblepulse.crates.core.Json;
import fr.cobblepulse.crates.net.Payloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5455;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;

/** Couleurs, dessin et petites aides partagees par les ecrans du passe et de l'editeur. */
public final class Ui {
    public static final int BG = 0xE00C0F14;
    public static final int PANEL = 0xF0161B24;
    public static final int PANEL2 = 0xF01E2530;
    public static final int CARD = 0xFF1A202A;
    public static final int CARD_ON = 0xFF223044;
    public static final int BORDER = 0xFF2E3A4C;
    public static final int ACCENT = 0xFF5FC8FF;
    public static final int GOLD = 0xFFFFD24A;
    public static final int GOLD_DARK = 0xFF7A5A12;
    public static final int TEXT = 0xFFE8ECF2;
    public static final int MUTED = 0xFF8E9AAB;
    public static final int OK = 0xFF6BE07A;
    public static final int ERROR = 0xFFFF6B6B;
    public static final int PURPLE = 0xFFC48CFF;

    private static final Map<String, class_1799> ITEM_CACHE = new HashMap<>();
    private static final Map<String, class_2561> COMP_CACHE = new HashMap<>();

    private Ui() {}

    public static class_327 font() {
        return class_310.method_1551().field_1772;
    }

    /** Registres du client (connexion en cours) ou registres integres (ecran titre, auto-test). */
    public static class_7225.class_7874 regs() {
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() != null) return mc.method_1562().method_29091();
        return class_5455.method_40302(class_7923.field_41167);
    }

    public static void clearCaches() {
        ITEM_CACHE.clear();
        COMP_CACHE.clear();
    }

    public static class_1799 item(String b64) {
        if (b64 == null || b64.isEmpty()) return class_1799.field_8037;
        class_1799 s = ITEM_CACHE.get(b64);
        if (s == null) {
            s = ItemSerial.decode(b64, regs());
            if (ITEM_CACHE.size() > 4000) ITEM_CACHE.clear();
            ITEM_CACHE.put(b64, s);
        }
        return s;
    }

    public static class_2561 comp(String json) {
        if (json == null || json.isEmpty()) return class_2561.method_43473();
        class_2561 c = COMP_CACHE.get(json);
        if (c == null) {
            try {
                c = class_2561.class_2562.method_10877(json, regs());
            } catch (Exception e) {
                c = class_2561.method_43470(json);
            }
            if (c == null) c = class_2561.method_43473();
            if (COMP_CACHE.size() > 4000) COMP_CACHE.clear();
            COMP_CACHE.put(json, c);
        }
        return c;
    }

    /** Objet decrit en JSON (format des fichiers de recompenses) ; la quantite peut depasser 99. */
    public static class_1799 itemJson(JsonElement json) {
        if (json == null || json.isJsonNull()) return class_1799.field_8037;
        try {
            int count = 1;
            JsonElement parse = json;
            if (json.isJsonObject()) {
                JsonObject o = json.getAsJsonObject().deepCopy();
                if (o.has("count")) count = Math.max(1, o.get("count").getAsInt());
                o.addProperty("count", 1);
                parse = o;
            }
            class_1799 s = class_1799.field_24671.parse(class_6903.method_46632(JsonOps.INSTANCE, regs()), parse).result().orElse(class_1799.field_8037);
            if (!s.method_7960()) s.method_7939(count);
            return s;
        } catch (Exception e) {
            return class_1799.field_8037;
        }
    }

    public static JsonElement encodeItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;
        int count = stack.method_7947();
        JsonElement e = class_1799.field_24671.encodeStart(class_6903.method_46632(JsonOps.INSTANCE, regs()), stack.method_46651(1)).result().orElse(null);
        if (e != null && e.isJsonObject()) e.getAsJsonObject().addProperty("count", count);
        return e;
    }

    public static class_1799 itemById(String id) {
        if (id == null || id.isBlank()) return class_1799.field_8037;
        String v = id.trim();
        class_2960 rl = class_2960.method_12829(v.contains(":") ? v : "minecraft:" + v);
        if (rl == null || !class_7923.field_41178.method_10250(rl)) {
            rl = class_2960.method_12829("cobblemon:" + (v.contains(":") ? v.substring(v.indexOf(':') + 1) : v));
            if (rl == null || !class_7923.field_41178.method_10250(rl)) return new class_1799(class_1802.field_8077);
        }
        class_1792 it = class_7923.field_41178.method_10223(rl);
        return new class_1799(it);
    }

    public static void send(String action, JsonElement args) {
        if (!ClientPlayNetworking.canSend(Payloads.Action.TYPE)) return;
        ClientPlayNetworking.send(new Payloads.Action(action, args == null ? "{}" : Json.COMPACT.toJson(args)));
    }

    public static void send(String action) {
        send(action, new JsonObject());
    }

    // ------------------------------------------------------------------ Echelle d'interface

    /**
     * Reduit l'echelle d'interface tant que l'ecran fait moins de minW x minH (en pixels d'interface).
     * @return l'echelle d'origine a restaurer a la fermeture, ou -1 si rien n'a change.
     */
    public static int fitScale(net.minecraft.class_437 screen, int minW, int minH, int saved) {
        net.minecraft.class_1041 win = class_310.method_1551().method_22683();
        int cur = (int) win.method_4495();
        int s = cur;
        while (s > 1 && (win.method_4489() / s < minW || win.method_4506() / s < minH)) s--;
        if (s != cur) {
            if (saved < 0) saved = cur;
            win.method_15997(s);
            screen.field_22789 = win.method_4486();
            screen.field_22790 = win.method_4502();
        }
        return saved;
    }

    public static int restoreScale(int saved) {
        if (saved > 0) class_310.method_1551().method_22683().method_15997(saved);
        return -1;
    }

    // ------------------------------------------------------------------ Couleurs et sons

    public static int argb(int alpha, int rgb) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0xFFFFFF);
    }

    /** Melange de deux couleurs RGB (t = 0 : a, t = 1 : b). */
    public static int mix(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int darken(int rgb, float f) {
        return mix(rgb, 0x000000, f);
    }

    public static int lighten(int rgb, float f) {
        return mix(rgb, 0xFFFFFF, f);
    }

    public static void playUi(String id, float pitch, float volume) {
        try {
            net.minecraft.class_2960 rl = id == null || id.isBlank() ? null
                    : net.minecraft.class_2960.method_12829(id.contains(":") ? id : "minecraft:" + id);
            if (rl == null) return;
            net.minecraft.class_3414 ev = class_7923.field_41172.method_10223(rl);
            if (ev == null) ev = net.minecraft.class_3414.method_47908(rl);
            class_310.method_1551().method_1483().method_4873(net.minecraft.class_1109.method_4757(ev, pitch, volume));
        } catch (Throwable ignored) {
        }
    }

    public static void playUi(net.minecraft.class_3414 ev, float pitch, float volume) {
        class_310.method_1551().method_1483().method_4873(net.minecraft.class_1109.method_4757(ev, pitch, volume));
    }

    // ------------------------------------------------------------------ Dessin

    public static void hgradient(class_332 g, int x, int y, int w, int h, int left, int right) {
        int steps = Math.max(1, Math.min(w, 32));
        for (int i = 0; i < steps; i++) {
            int x0 = x + i * w / steps;
            int x1 = x + (i + 1) * w / steps;
            float t = steps == 1 ? 0 : (float) i / (steps - 1);
            int a = (int) (((left >>> 24) & 255) * (1 - t) + ((right >>> 24) & 255) * t);
            int c = mix(left & 0xFFFFFF, right & 0xFFFFFF, t);
            g.method_25294(x0, y, x1, y + h, argb(a, c));
        }
    }

    /** Cadre de 1 px. */
    public static void frame(class_332 g, int x, int y, int w, int h, int color) {
        g.method_25294(x, y, x + w, y + 1, color);
        g.method_25294(x, y + h - 1, x + w, y + h, color);
        g.method_25294(x, y, x + 1, y + h, color);
        g.method_25294(x + w - 1, y, x + w, y + h, color);
    }

    public static void panel(class_332 g, int x, int y, int w, int h, int fill, int border) {
        g.method_25294(x, y, x + w, y + h, border);
        g.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    public static void bar(class_332 g, int x, int y, int w, int h, double pct, int color) {
        g.method_25294(x, y, x + w, y + h, 0xFF0B0E13);
        g.method_25294(x, y, x + w, y + 1, BORDER);
        int fw = (int) Math.round((w - 2) * Math.max(0, Math.min(1, pct)));
        if (fw > 0) g.method_25294(x + 1, y + 1, x + 1 + fw, y + h - 1, color);
    }

    public static void item(class_332 g, class_1799 s, int x, int y, float scale, boolean decorations) {
        if (s == null || s.method_7960()) return;
        g.method_51448().method_22903();
        g.method_51448().method_46416(x, y, 0);
        g.method_51448().method_22905(scale, scale, 1f);
        g.method_51427(s, 0, 0);
        if (decorations) g.method_51431(font(), s, 0, 0);
        g.method_51448().method_22909();
    }

    /**
     * Objet centre sur (cx, cy) a l'echelle donnee ; les icones de Pokemon (modele 3D, plus petit qu'un objet)
     * sont agrandies de {@code pokemonBoost}.
     */
    public static void icon(class_332 g, class_1799 s, int cx, int cy, float scale, float pokemonBoost, boolean decorations) {
        if (s == null || s.method_7960()) return;
        float sc = s.method_7909() instanceof com.cobblemon.mod.common.item.PokemonItem ? scale * pokemonBoost : scale;
        g.method_51448().method_22903();
        g.method_51448().method_46416(cx - 8 * sc, cy - 8 * sc, 0);
        g.method_51448().method_22905(sc, sc, 1f);
        g.method_51427(s, 0, 0);
        if (decorations) g.method_51431(font(), s, 0, 0);
        g.method_51448().method_22909();
    }

    public static String cut(String s, int width) {
        class_327 f = font();
        if (f.method_1727(s) <= width) return s;
        return f.method_27523(s, Math.max(0, width - f.method_1727("…"))) + "…";
    }

    public static void text(class_332 g, String s, int x, int y, int color) {
        g.method_51433(font(), s, x, y, color, false);
    }

    public static void text(class_332 g, class_2561 c, int x, int y, int color) {
        g.method_51439(font(), c, x, y, color, false);
    }

    public static void centered(class_332 g, String s, int cx, int y, int color) {
        g.method_51433(font(), s, cx - font().method_1727(s) / 2, y, color, false);
    }

    public static void scaled(class_332 g, String s, int x, int y, int color, float scale) {
        g.method_51448().method_22903();
        g.method_51448().method_46416(x, y, 0);
        g.method_51448().method_22905(scale, scale, 1f);
        g.method_51433(font(), s, 0, 0, color, false);
        g.method_51448().method_22909();
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }

    /** Duree lisible : 3j 4h, 2h 5min, 45s. */
    public static String duration(long ms) {
        if (ms <= 0) return "0s";
        long s = ms / 1000;
        long d = s / 86400;
        long h = (s % 86400) / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (d > 0) return d + "j " + h + "h";
        if (h > 0) return h + "h " + m + "min";
        if (m > 0) return m + "min " + sec + "s";
        return sec + "s";
    }

    public static String num(long n) {
        String s = String.valueOf(Math.abs(n));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append(' ');
            b.append(s.charAt(i));
        }
        return (n < 0 ? "-" : "") + b;
    }

    public static String str(JsonObject o, String k, String def) {
        try {
            return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : def;
        } catch (Exception e) {
            return def;
        }
    }

    public static long lng(JsonObject o, String k, long def) {
        try {
            return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsLong() : def;
        } catch (Exception e) {
            return def;
        }
    }

    public static double dbl(JsonObject o, String k, double def) {
        try {
            return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsDouble() : def;
        } catch (Exception e) {
            return def;
        }
    }

    public static boolean bool(JsonObject o, String k, boolean def) {
        try {
            return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsBoolean() : def;
        } catch (Exception e) {
            return def;
        }
    }

    public static JsonObject obj(JsonObject o, String k) {
        if (o == null) return new JsonObject();
        if (!o.has(k) || !o.get(k).isJsonObject()) o.add(k, new JsonObject());
        return o.getAsJsonObject(k);
    }

    public static com.google.gson.JsonArray arr(JsonObject o, String k) {
        if (o == null) return new com.google.gson.JsonArray();
        if (!o.has(k) || !o.get(k).isJsonArray()) o.add(k, new com.google.gson.JsonArray());
        return o.getAsJsonArray(k);
    }
}

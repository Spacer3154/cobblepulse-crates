package fr.cobblepulse.crates.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

/**
 * Formulaire defilant : une ligne = un libelle + un champ lie a une propriete d'un objet JSON
 * (texte, entier, decimal, oui/non, choix, liste separee par des virgules, table cle:valeur, bouton).
 */
public final class Form {
    private static final int ROW = 22;

    private final class Row {
        final String label;
        final String tip;
        final List<class_339> widgets = new ArrayList<>();
        final boolean section;
        int y;

        Row(String label, String tip, boolean section) {
            this.label = label;
            this.tip = tip;
            this.section = section;
        }
    }

    private final Consumer<class_339> adder;
    private final List<Row> rows = new ArrayList<>();
    private final Map<class_342, Function<String, List<String>>> suggesters = new java.util.HashMap<>();
    private int x;
    private int y;
    private int w;
    private int h;
    private int labelW;
    private double scroll;
    private List<String> shownSuggestions = new ArrayList<>();
    private class_342 suggestBox;
    private Runnable onChange = () -> {};

    public Form(Consumer<class_339> adder, int x, int y, int w, int h) {
        this.adder = adder;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.labelW = Math.min(170, Math.max(90, w * 2 / 5));
    }

    public Form onChange(Runnable r) {
        this.onChange = r == null ? () -> {} : r;
        return this;
    }

    public void setScroll(double s) {
        this.scroll = s;
    }

    public double scroll() {
        return scroll;
    }

    private Row row(String label, String tip) {
        Row r = new Row(label, tip, false);
        rows.add(r);
        return r;
    }

    private <T extends class_339> T add(Row r, T widget) {
        if (r.tip != null && !r.tip.isEmpty()) widget.method_47400(class_7919.method_47407(class_2561.method_43470(r.tip)));
        r.widgets.add(widget);
        adder.accept(widget);
        return widget;
    }

    public void section(String title) {
        rows.add(new Row(title, null, true));
    }

    private class_342 box(Row r, String value) {
        class_342 b = new class_342(Ui.font(), 0, 0, 100, 18, class_2561.method_43470(r.label));
        b.method_1880(4096);
        b.method_1852(value == null ? "" : value);
        b.method_1870(false);
        return add(r, b);
    }

    public class_342 text(String label, JsonObject obj, String key, String tip) {
        Row r = row(label, tip);
        class_342 b = box(r, Ui.str(obj, key, ""));
        b.method_1863(v -> {
            obj.addProperty(key, v);
            onChange.run();
        });
        return b;
    }

    public class_342 integer(String label, JsonObject obj, String key, int min, int max, String tip) {
        Row r = row(label, tip);
        class_342 b = box(r, String.valueOf(Ui.lng(obj, key, 0)));
        b.method_1890(s -> s.isEmpty() || s.equals("-") || s.matches("-?\\d{0,10}"));
        b.method_1863(v -> {
            try {
                long n = Long.parseLong(v.trim());
                obj.addProperty(key, (int) Math.max(min, Math.min(max, n)));
                b.method_1868(0xFFE0E0E0);
                onChange.run();
            } catch (NumberFormatException e) {
                b.method_1868(0xFFFF6B6B);
            }
        });
        return b;
    }

    public class_342 decimal(String label, JsonObject obj, String key, String tip) {
        Row r = row(label, tip);
        double d = Ui.dbl(obj, key, 0);
        class_342 b = box(r, d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d));
        b.method_1890(s -> s.isEmpty() || s.matches("-?\\d{0,12}([.,]\\d{0,6})?"));
        b.method_1863(v -> {
            try {
                obj.addProperty(key, Double.parseDouble(v.trim().replace(',', '.')));
                b.method_1868(0xFFE0E0E0);
                onChange.run();
            } catch (NumberFormatException e) {
                b.method_1868(0xFFFF6B6B);
            }
        });
        return b;
    }

    public class_4185 bool(String label, JsonObject obj, String key, String tip) {
        Row r = row(label, tip);
        class_4185 b = class_4185.method_46430(class_2561.method_43470(Ui.bool(obj, key, false) ? "Oui" : "Non"), btn -> {
            boolean v = !Ui.bool(obj, key, false);
            obj.addProperty(key, v);
            btn.method_25355(class_2561.method_43470(v ? "Oui" : "Non"));
            onChange.run();
        }).method_46434(0, 0, 100, 18).method_46431();
        return add(r, b);
    }

    /** Choix parmi des valeurs (libelles affiches). */
    public class_4185 choice(String label, JsonObject obj, String key, List<String> values, List<String> names, String tip) {
        Row r = row(label, tip);
        String cur = Ui.str(obj, key, values.isEmpty() ? "" : values.get(0));
        int idx = Math.max(0, values.indexOf(cur));
        class_4185 b = class_4185.method_46430(class_2561.method_43470(names.get(idx)), btn -> {
            String c = Ui.str(obj, key, values.get(0));
            int i = (values.indexOf(c) + (net.minecraft.class_437.method_25442() ? values.size() - 1 : 1)) % values.size();
            obj.addProperty(key, values.get(i));
            btn.method_25355(class_2561.method_43470(names.get(i)));
            onChange.run();
        }).method_46434(0, 0, 100, 18).method_46431();
        return add(r, b);
    }

    private static String joinList(JsonObject obj, String key) {
        List<String> out = new ArrayList<>();
        if (obj.has(key) && obj.get(key).isJsonArray()) for (JsonElement e : obj.getAsJsonArray(key)) out.add(e.getAsString());
        return String.join(", ", out);
    }

    /** Liste de textes separes par des virgules. */
    public class_342 list(String label, JsonObject obj, String key, String tip) {
        Row r = row(label, tip);
        class_342 b = box(r, joinList(obj, key));
        b.method_1863(v -> {
            JsonArray a = new JsonArray();
            for (String s : v.split(",")) if (!s.isBlank()) a.add(s.trim());
            obj.add(key, a);
            onChange.run();
        });
        return b;
    }

    public class_342 intList(String label, JsonObject obj, String key, String tip) {
        Row r = row(label, tip);
        class_342 b = box(r, joinList(obj, key));
        b.method_1863(v -> {
            JsonArray a = new JsonArray();
            for (String s : v.split(",")) {
                try {
                    if (!s.isBlank()) a.add(Integer.parseInt(s.trim()));
                } catch (NumberFormatException ignored) {
                }
            }
            obj.add(key, a);
            onChange.run();
        });
        return b;
    }

    /** Table cle:valeur entiere ("7:500, 14:1000"). */
    public class_342 intMap(String label, JsonObject obj, String key, String tip) {
        Row r = row(label, tip);
        List<String> parts = new ArrayList<>();
        if (obj.has(key) && obj.get(key).isJsonObject()) {
            for (Map.Entry<String, JsonElement> e : obj.getAsJsonObject(key).entrySet()) parts.add(e.getKey() + ":" + e.getValue().getAsString());
        }
        class_342 b = box(r, String.join(", ", parts));
        b.method_1863(v -> {
            JsonObject m = new JsonObject();
            for (String s : v.split(",")) {
                String[] kv = s.split(":");
                if (kv.length != 2) continue;
                try {
                    m.add(kv[0].trim(), new JsonPrimitive(Integer.parseInt(kv[1].trim())));
                } catch (NumberFormatException ignored) {
                }
            }
            obj.add(key, m);
            onChange.run();
        });
        return b;
    }

    public class_4185 button(String label, String text, Runnable action, String tip) {
        Row r = row(label, tip);
        class_4185 b = class_4185.method_46430(class_2561.method_43470(text), btn -> action.run()).method_46434(0, 0, 100, 18).method_46431();
        return add(r, b);
    }

    /** Ligne de plusieurs boutons. */
    public List<class_4185> buttons(String label, List<String> texts, List<Runnable> actions) {
        Row r = row(label, null);
        List<class_4185> out = new ArrayList<>();
        for (int i = 0; i < texts.size(); i++) {
            Runnable a = actions.get(i);
            out.add(add(r, class_4185.method_46430(class_2561.method_43470(texts.get(i)), btn -> a.run()).method_46434(0, 0, 60, 18).method_46431()));
        }
        return out;
    }

    /** Plusieurs entiers sur une ligne (IV, EV...) lies aux cles d'un objet JSON. */
    public List<class_342> intRow(String label, JsonObject obj, List<String> keys, int min, int max, String tip) {
        Row r = row(label, tip);
        List<class_342> out = new ArrayList<>();
        for (String key : keys) {
            class_342 b = box(r, String.valueOf(Ui.lng(obj, key, 0)));
            b.method_1890(s -> s.isEmpty() || s.equals("-") || s.matches("-?\\d{0,4}"));
            b.method_1863(v -> {
                try {
                    obj.addProperty(key, (int) Math.max(min, Math.min(max, Long.parseLong(v.trim()))));
                    b.method_1868(0xFFE0E0E0);
                    onChange.run();
                } catch (NumberFormatException e) {
                    b.method_1868(0xFFFF6B6B);
                }
            });
            out.add(b);
        }
        return out;
    }

    /** Plusieurs textes sur une ligne lies aux elements d'un tableau JSON (ex. 4 capacites). */
    public List<class_342> textRow(String label, JsonObject obj, String key, int count, String tip) {
        Row r = row(label, tip);
        List<class_342> out = new ArrayList<>();
        List<class_342> boxes = new ArrayList<>();
        JsonArray cur = obj.has(key) && obj.get(key).isJsonArray() ? obj.getAsJsonArray(key) : new JsonArray();
        for (int i = 0; i < count; i++) {
            class_342 b = box(r, i < cur.size() ? cur.get(i).getAsString() : "");
            boxes.add(b);
            out.add(b);
        }
        for (class_342 b : boxes) {
            b.method_1863(v -> {
                JsonArray a = new JsonArray();
                for (class_342 x : boxes) if (!x.method_1882().isBlank()) a.add(x.method_1882().trim());
                obj.add(key, a);
                onChange.run();
            });
        }
        return out;
    }

    /** Champ libre (non lie) : la valeur est lue par l'appelant. */
    public class_342 free(String label, String value, String tip) {
        Row r = row(label, tip);
        return box(r, value);
    }

    public void suggest(class_342 box, Function<String, List<String>> fn) {
        suggesters.put(box, fn);
    }

    public int contentHeight() {
        int hh = 0;
        for (Row r : rows) hh += r.section ? 16 : ROW;
        return hh + 4;
    }

    private int maxScroll() {
        return Math.max(0, contentHeight() - h);
    }

    /** Place les champs selon le defilement (les champs hors de la zone sont masques). */
    public void layout() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        int cy = y - (int) scroll;
        int fx = x + labelW + 4;
        int fw = w - labelW - 10;
        for (Row r : rows) {
            r.y = cy;
            int rh = r.section ? 16 : ROW;
            if (!r.widgets.isEmpty()) {
                int n = r.widgets.size();
                int gap = 4;
                int each = (fw - gap * (n - 1)) / n;
                for (int i = 0; i < n; i++) {
                    class_339 wd = r.widgets.get(i);
                    wd.method_46421(fx + i * (each + gap));
                    wd.method_46419(cy + 1);
                    wd.method_25358(each);
                    boolean vis = cy >= y - 1 && cy + 19 <= y + h + 1;
                    wd.field_22764 = vis;
                }
            }
            cy += rh;
        }
    }

    public boolean mouseScrolled(double mx, double my, double delta) {
        if (!Ui.in(mx, my, x, y, w, h)) return false;
        scroll -= delta * 24;
        layout();
        return true;
    }

    public boolean mouseClicked(double mx, double my) {
        if (suggestBox != null && suggestBox.field_22764 && suggestBox.method_25370() && !shownSuggestions.isEmpty()) {
            int sx = suggestBox.method_46426();
            int sy = suggestBox.method_46427() + 19;
            for (int i = 0; i < shownSuggestions.size(); i++) {
                if (Ui.in(mx, my, sx, sy + i * 11, suggestBox.method_25368(), 11)) {
                    String cur = suggestBox.method_1882();
                    int comma = cur.lastIndexOf(',');
                    String head = comma >= 0 ? cur.substring(0, comma + 1) + " " : "";
                    suggestBox.method_1852(head + shownSuggestions.get(i));
                    shownSuggestions = new ArrayList<>();
                    return true;
                }
            }
        }
        return false;
    }

    public void render(class_332 g, int mouseX, int mouseY) {
        g.method_44379(x, y, x + w, y + h);
        for (Row r : rows) {
            if (r.y + 20 < y || r.y > y + h) continue;
            if (r.section) {
                Ui.text(g, r.label, x + 2, r.y + 5, Ui.GOLD);
                g.method_25294(x + 2 + Ui.font().method_1727(r.label) + 4, r.y + 9, x + w - 6, r.y + 10, Ui.BORDER);
            } else {
                Ui.text(g, Ui.cut(r.label, labelW - 4), x + 4, r.y + 6, r.tip != null && Ui.in(mouseX, mouseY, x, r.y, labelW, 20) ? Ui.ACCENT : Ui.TEXT);
            }
        }
        g.method_44380();
        int max = maxScroll();
        if (max > 0) {
            int th = Math.max(16, h * h / contentHeight());
            int ty = y + (int) ((h - th) * (scroll / max));
            g.method_25294(x + w - 3, y, x + w - 1, y + h, 0x40FFFFFF);
            g.method_25294(x + w - 3, ty, x + w - 1, ty + th, 0xC0FFFFFF);
        }
        // Infobulle du libelle
        for (Row r : rows) {
            if (r.tip != null && !r.section && r.y >= y && r.y + 20 <= y + h && Ui.in(mouseX, mouseY, x, r.y, labelW, 20)) {
                g.method_51447(Ui.font(), Ui.font().method_1728(class_2561.method_43470(r.tip), 220), mouseX, mouseY);
            }
        }
        // Suggestions
        shownSuggestions = new ArrayList<>();
        suggestBox = null;
        for (Map.Entry<class_342, Function<String, List<String>>> e : suggesters.entrySet()) {
            class_342 b = e.getKey();
            if (!b.field_22764 || !b.method_25370()) continue;
            String cur = b.method_1882();
            int comma = cur.lastIndexOf(',');
            String token = (comma >= 0 ? cur.substring(comma + 1) : cur).trim().toLowerCase(Locale.ROOT);
            if (token.length() < 2) continue;
            List<String> s = e.getValue().apply(token);
            if (s.isEmpty() || (s.size() == 1 && s.get(0).equalsIgnoreCase(token))) continue;
            suggestBox = b;
            shownSuggestions = s.subList(0, Math.min(6, s.size()));
            int sx = b.method_46426();
            int sy = b.method_46427() + 19;
            g.method_51448().method_22903();
            g.method_51448().method_46416(0, 0, 400);
            g.method_25294(sx, sy, sx + b.method_25368(), sy + shownSuggestions.size() * 11 + 1, 0xF0000000);
            for (int i = 0; i < shownSuggestions.size(); i++) {
                boolean hov = Ui.in(mouseX, mouseY, sx, sy + i * 11, b.method_25368(), 11);
                Ui.text(g, Ui.cut(shownSuggestions.get(i), b.method_25368() - 4), sx + 2, sy + 2 + i * 11, hov ? Ui.GOLD : Ui.TEXT);
            }
            g.method_51448().method_22909();
            break;
        }
    }
}

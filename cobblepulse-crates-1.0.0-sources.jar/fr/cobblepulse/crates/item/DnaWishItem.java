package fr.cobblepulse.crates.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

/** Voeu ADN : monnaie evenementielle depensee dans le menu de remodelage (/cpbuilder). */
public class DnaWishItem extends class_1792 {
    private static final int[] IRIDESCENT = {0xFFB3E6, 0xC9B8FF, 0xA6E4FF, 0xA8FFD8, 0xFFF2A8, 0xFFC4A8};

    public DnaWishItem(class_1793 props) {
        super(props);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        String name = class_2561.method_43471(method_7876()).getString();
        class_5250 out = class_2561.method_43473();
        int n = Math.max(1, name.length());
        for (int i = 0; i < name.length(); i++) {
            float t = (float) i / n * (IRIDESCENT.length - 1);
            int a = IRIDESCENT[(int) Math.floor(t)];
            int b = IRIDESCENT[Math.min(IRIDESCENT.length - 1, (int) Math.floor(t) + 1)];
            float f = t - (float) Math.floor(t);
            int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
            int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
            int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
            int rgb = (r << 16) | (g << 8) | bl;
            out.method_10852(class_2561.method_43470(String.valueOf(name.charAt(i))).method_27694(s -> s.method_36139(rgb)));
        }
        return out;
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return false;
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 ctx, List<class_2561> lines, class_1836 flag) {
        lines.add(class_2561.method_43471(method_7876() + ".desc").method_27695(class_124.field_1080, class_124.field_1056));
        lines.add(class_2561.method_43471("item.cobblepulse_crates.voeu_adn.usage").method_27692(class_124.field_1076));
    }
}

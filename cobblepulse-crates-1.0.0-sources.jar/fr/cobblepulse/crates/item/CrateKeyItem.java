package fr.cobblepulse.crates.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

/** Cle fantasy : consommable sans effet, sert uniquement a ouvrir la caisse associee. */
public class CrateKeyItem extends class_1792 {
    private final KeyType key;

    public CrateKeyItem(KeyType key, class_1793 props) {
        super(props);
        this.key = key;
    }

    public KeyType key() {
        return key;
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(method_7876()).method_27694(s -> s.method_36139(key.color));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 ctx, List<class_2561> lines, class_1836 flag) {
        lines.add(class_2561.method_43471(method_7876() + ".desc").method_27695(class_124.field_1080, class_124.field_1056));
        lines.add(class_2561.method_43471("item.cobblepulse_crates.key.usage").method_27692(class_124.field_1063));
    }
}

package fr.cobblepulse.crates.item;

import fr.cobblepulse.crates.Crates;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.EnumMap;
import java.util.Map;

/** Enregistrement des 10 cles, du Voeu ADN et de l'onglet creatif. */
public final class ModItems {
    public static final Map<KeyType, CrateKeyItem> KEYS = new EnumMap<>(KeyType.class);
    public static DnaWishItem VOEU_ADN;

    private ModItems() {}

    private static class_2960 id(String path) {
        return class_2960.method_60655(Crates.MOD_ID, path);
    }

    public static void register() {
        for (KeyType k : KeyType.values()) {
            class_1814 r = switch (k) {
                case COEUR_DRAGON, TEMPS, CELESTE -> class_1814.field_8904;
                case SOLAIRE, OMBRE, PROFONDEURS -> class_1814.field_8903;
                default -> class_1814.field_8907;
            };
            CrateKeyItem item = class_2378.method_10230(class_7923.field_41178, id(k.itemPath()), new CrateKeyItem(k, new class_1792.class_1793().method_7889(64).method_7894(r)));
            KEYS.put(k, item);
        }
        VOEU_ADN = class_2378.method_10230(class_7923.field_41178, id("voeu_adn"), new DnaWishItem(new class_1792.class_1793().method_7889(64).method_7894(class_1814.field_8904)));
        class_2378.method_10230(class_7923.field_44687, id("onglet"), FabricItemGroup.builder()
                .method_47320(() -> new class_1799(KEYS.get(KeyType.COEUR_DRAGON)))
                .method_47321(class_2561.method_43471("itemGroup.cobblepulse_crates"))
                .method_47317((params, out) -> {
                    for (KeyType k : KeyType.values()) out.method_45421(KEYS.get(k));
                    out.method_45421(VOEU_ADN);
                })
                .method_47324());
    }

    public static boolean isKey(class_1792 item) {
        return item instanceof CrateKeyItem;
    }
}

package fr.cobblepulse.crates.core;

import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

/** Conversion des codes couleur legacy (&a, &l, &#RRGGBB) en composants texte. */
public final class TextUtil {
    private TextUtil() {}

    public static class_5250 legacy(String input) {
        class_5250 root = class_2561.method_43473();
        if (input == null || input.isEmpty()) return root;
        class_2583 style = class_2583.field_24360;
        StringBuilder buf = new StringBuilder();
        int i = 0;
        int n = input.length();
        while (i < n) {
            char c = input.charAt(i);
            if (c == '<' && i + 9 <= n && input.charAt(i + 1) == '#' && input.charAt(i + 8) == '>' && isHex(input, i + 2, 6)) {
                flush(root, buf, style);
                style = class_2583.field_24360.method_27703(class_5251.method_27717(Integer.parseInt(input.substring(i + 2, i + 8), 16)));
                i += 9;
                continue;
            }
            if (c == '<' && input.startsWith("</#>", i)) {
                flush(root, buf, style);
                style = class_2583.field_24360;
                i += 4;
                continue;
            }
            if ((c == '&' || c == '§') && i + 1 < n) {
                char code = Character.toLowerCase(input.charAt(i + 1));
                if (code == '#' && i + 8 <= n && isHex(input, i + 2, 6)) {
                    flush(root, buf, style);
                    int rgb = Integer.parseInt(input.substring(i + 2, i + 8), 16);
                    style = class_2583.field_24360.method_27703(class_5251.method_27717(rgb));
                    i += 8;
                    continue;
                }
                class_124 fmt = class_124.method_544(code);
                if (fmt != null) {
                    flush(root, buf, style);
                    if (fmt == class_124.field_1070) {
                        style = class_2583.field_24360;
                    } else if (fmt.method_543()) {
                        style = class_2583.field_24360.method_10977(fmt);
                    } else {
                        style = style.method_27706(fmt);
                    }
                    i += 2;
                    continue;
                }
            }
            buf.append(c);
            i++;
        }
        flush(root, buf, style);
        return root;
    }

    private static boolean isHex(String s, int from, int len) {
        if (from + len > s.length()) return false;
        for (int k = from; k < from + len; k++) {
            if (Character.digit(s.charAt(k), 16) < 0) return false;
        }
        return true;
    }

    private static void flush(class_5250 root, StringBuilder buf, class_2583 style) {
        if (buf.length() == 0) return;
        root.method_10852(class_2561.method_43470(buf.toString()).method_10862(style));
        buf.setLength(0);
    }

    /** Retire les codes couleur d'une chaine. */
    public static String strip(String input) {
        if (input == null) return "";
        return input.replaceAll("(?i)<#[0-9a-f]{6}>|</#>", "").replaceAll("(?i)[&§]#[0-9a-f]{6}", "").replaceAll("(?i)[&§][0-9a-fk-or]", "");
    }

    /** Version non italique (utile pour les noms/lores d'items). */
    public static class_5250 item(String legacy) {
        return class_2561.method_43473().method_27694(s -> s.method_10978(false)).method_10852(legacy(legacy));
    }

    public static class_5250 button(String legacyLabel, String command, String legacyHover) {
        class_5250 c = legacy(legacyLabel);
        class_2583 st = class_2583.field_24360.method_10958(new class_2558(class_2558.class_2559.field_11750, command));
        if (legacyHover != null) {
            st = st.method_10949(new class_2568(class_2568.class_5247.field_24342, legacy(legacyHover)));
        }
        return class_2561.method_43473().method_10862(st).method_10852(c);
    }
}

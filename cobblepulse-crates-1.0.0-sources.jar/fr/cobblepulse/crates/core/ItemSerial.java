package fr.cobblepulse.crates.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_7225;

/** Objet <-> texte (NBT compresse en Base64), pour l'affichage cote client. Utilisable cote serveur et client. */
public final class ItemSerial {
    private ItemSerial() {}

    public static String encode(class_1799 stack, class_7225.class_7874 regs) {
        if (stack == null || stack.method_7960() || regs == null) return "";
        try {
            int count = stack.method_7947();
            class_2520 t = stack.method_46651(Math.max(1, Math.min(99, count))).method_57358(regs);
            class_2487 root = new class_2487();
            root.method_10566("i", t);
            root.method_10569("n", count);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            class_2507.method_10634(root, out);
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (Exception e) {
            return "";
        }
    }

    public static class_1799 decode(String data, class_7225.class_7874 regs) {
        if (data == null || data.isEmpty() || regs == null) return class_1799.field_8037;
        try {
            class_2487 root = class_2507.method_10629(new ByteArrayInputStream(Base64.getDecoder().decode(data)), class_2505.method_53898());
            class_1799 s = class_1799.method_57359(regs, root.method_10562("i"));
            if (!s.method_7960() && root.method_10545("n")) s.method_7939(Math.max(1, root.method_10550("n")));
            return s;
        } catch (Exception e) {
            return class_1799.field_8037;
        }
    }
}

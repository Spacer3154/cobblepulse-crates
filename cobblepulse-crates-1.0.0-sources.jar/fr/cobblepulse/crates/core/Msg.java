package fr.cobblepulse.crates.core;

import fr.cobblepulse.crates.Crates;
import fr.cobblepulse.crates.config.Cfg;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;

/** Messages configurables (messages.toml) avec variables %cle%. */
public final class Msg {
    private Msg() {}

    public static String raw(String key) {
        if (Cfg.messages == null) return key;
        String v = Cfg.messages.str(key, null);
        if (v == null) {
            Crates.LOG.warn("[Crates] Message manquant dans messages.toml : {}", key);
            return key;
        }
        return v;
    }

    public static String format(String key, Object... kv) {
        String s = raw(key);
        if (s.contains("%prefix_adn%")) s = s.replace("%prefix_adn%", raw("builder.prefix"));
        if (s.contains("%prefix%")) s = s.replace("%prefix%", raw("general.prefix"));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("%" + kv[i] + "%", String.valueOf(kv[i + 1]));
        }
        return s;
    }

    public static class_5250 get(String key, Object... kv) {
        return TextUtil.legacy(format(key, kv));
    }

    /** Message dont une variable est un composant (nom d'objet traduit, Pokemon...). */
    public static class_5250 withComponent(String key, String var, class_2561 value, Object... kv) {
        String s = format(key, kv);
        String token = "%" + var + "%";
        int i = s.indexOf(token);
        if (i < 0) return TextUtil.legacy(s);
        class_5250 out = class_2561.method_43473();
        out.method_10852(TextUtil.legacy(s.substring(0, i)));
        out.method_10852(value);
        out.method_10852(TextUtil.legacy(s.substring(i + token.length())));
        return out;
    }

    public static boolean reachable(class_3222 p) {
        return p != null && p.field_13987 != null && !Players.isTest(p.method_5667());
    }

    public static void send(class_3222 p, String key, Object... kv) {
        if (reachable(p)) p.method_43496(get(key, kv));
    }

    public static void send(class_2168 src, String key, Object... kv) {
        src.method_45068(get(key, kv));
    }

    public static void broadcast(class_2561 c) {
        MinecraftServer s = Crates.server();
        if (s != null) s.method_3760().method_43514(c, false);
    }

    public static void actionBar(class_3222 p, String key, Object... kv) {
        if (reachable(p)) p.method_7353(get(key, kv), true);
    }
}

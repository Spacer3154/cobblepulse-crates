package fr.cobblepulse.crates.core;

import fr.cobblepulse.crates.integration.LuckPermsBridge;
import java.util.Locale;
import java.util.function.Predicate;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

/**
 * Permissions (LuckPerms). Sans LuckPerms, ou si le noeud n'est pas defini : noeuds joueurs autorises,
 * administration = operateurs niveau 3, contournements (bypass) = accordes explicitement seulement
 * (sauf contournement de maintenance : operateurs niveau 3).
 */
public final class Perms {
    public static final String ROOT = "cobblepulsecrates";
    public static final String PREVIEW = ROOT + ".command.preview";
    public static final String BUILDER_OPEN = ROOT + ".builder.open";
    public static final String BUILDER_USE = ROOT + ".builder.use";
    public static final String BUILDER_BYPASS = ROOT + ".builder.bypass";
    public static final String BYPASS_MAINTENANCE = ROOT + ".bypass.maintenance";
    public static final String CRATE_OPEN = ROOT + ".crate.open.";
    public static final String ADMIN = ROOT + ".admin";
    public static final String ADMIN_SET = ADMIN + ".set";
    public static final String ADMIN_UNSET = ADMIN + ".unset";
    public static final String ADMIN_EDITOR = ADMIN + ".editor";
    public static final String ADMIN_TOGGLE = ADMIN + ".toggle";
    public static final String ADMIN_GIVEKEY = ADMIN + ".givekey";
    public static final String ADMIN_GIVEWISH = ADMIN + ".givewish";
    public static final String ADMIN_RELOAD = ADMIN + ".reload";

    private Perms() {}

    /** Noeud joueur : autorise sauf refus explicite. */
    public static boolean player(class_3222 p, String node) {
        Boolean v = LuckPermsBridge.check(p, node);
        return v == null || v;
    }

    /** Noeud d'administration : le noeud precis, sinon le joker admin.*, sinon operateur niveau 3. */
    public static boolean admin(class_3222 p, String node) {
        if (p == null) return true;
        Boolean v = LuckPermsBridge.check(p, node);
        if (v != null) return v;
        Boolean all = LuckPermsBridge.check(p, ADMIN + ".*");
        return all != null ? all : p.method_5687(3);
    }

    public static boolean canOpen(class_3222 p, String crate) {
        return player(p, CRATE_OPEN + crate.toLowerCase(Locale.ROOT));
    }

    public static boolean bypassMaintenance(class_3222 p) {
        Boolean v = LuckPermsBridge.check(p, BYPASS_MAINTENANCE);
        return v != null ? v : p.method_5687(3);
    }

    /** Remodelage sans consommer de Voeu ADN : uniquement si le noeud est accorde. */
    public static boolean builderBypass(class_3222 p) {
        Boolean v = LuckPermsBridge.check(p, BUILDER_BYPASS);
        return v != null && v;
    }

    public static Predicate<class_2168> playerReq(String node) {
        return src -> !src.method_43737() || player(src.method_44023(), node);
    }

    public static Predicate<class_2168> adminReq(String node) {
        return src -> !src.method_43737() || admin(src.method_44023(), node);
    }

    public static boolean anyAdmin(class_3222 p) {
        return admin(p, ADMIN_EDITOR) || admin(p, ADMIN_SET) || admin(p, ADMIN_TOGGLE) || admin(p, ADMIN_RELOAD);
    }
}
